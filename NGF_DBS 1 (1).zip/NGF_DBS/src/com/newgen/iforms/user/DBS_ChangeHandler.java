package com.newgen.iforms.user;

import java.util.List;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.newgen.iforms.custom.IFormReference;

public class DBS_ChangeHandler extends DBSCommon {

	private static final String EXCEPTION_OCCURED = null;
	private static final String UNHANDLED = null;
	private static final String SUCCESS = null;
	private static final String FAIL = null;
	private String WI_Name = null;
	private String WI_ID = null;
	private String actName = null;
	private String userName = null;
	private String inputString = null;
	private IFormReference giformObj = null;

	public String onChange(IFormReference iformObj, String control, String stringdata) {
		DBS.mLogger.info("Inside onChange method of DBO_ChangeHandler with control id-- " + control);
		WI_Name = getWorkitemName(iformObj);
		WI_ID=(iformObj).getObjGeneralData().getM_strWorkitemId();
		actName = iformObj.getActivityName();
		userName = iformObj.getUserName();
		inputString = stringdata;
		giformObj = iformObj;
		try {
			
			if ("ID_DECISION".equalsIgnoreCase(control)) {
				String decision =  (String) iformObj.getValue("ID_DECISION");
				if(decision.equalsIgnoreCase("Reject")) {
					iformObj.setStyle("REJECT_REASON_GRID", "visible", "true");
					//iformObj.setStyle("REJECT_REASON_GRID", "mandatory", "true");
				}
				else {
					 iformObj.clearTable("REJECT_REASON_GRID");
					// iformObj.setStyle("REJECT_REASON_GRID", "mandatory", "false");
					iformObj.setStyle("REJECT_REASON_GRID", "visible", "false");
			}}
		} catch (Exception exc) {
			DBS.printException(exc);
			DBS.mLogger.debug("Exception 2 - " + exc);
		}

		return UNHANDLED;
	}

}
