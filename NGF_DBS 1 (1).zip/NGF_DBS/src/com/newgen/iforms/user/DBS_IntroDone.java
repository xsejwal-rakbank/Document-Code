package com.newgen.iforms.user;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.newgen.iforms.custom.IFormReference;

public class DBS_IntroDone extends DBSCommon{
	
	private String WI_Name = null;
	private String activityName = null;
	public String onIntroduceDone(IFormReference iformObj,String controlName,String data) throws IOException
	{
		DBS.mLogger.info("Inside onIntroduceDone...");
		String strReturn="";
		WI_Name=getWorkitemName(iformObj);
		activityName=iformObj.getActivityName();
		DBS.mLogger.info("WINAME: "+WI_Name+", WSNAME: "+activityName+", ControlName: "+controlName+", This is DBS_IntroDone");
		//iformObj.setValue("AWBNO",(String)iformObj.getValue(serviceReqCode+"_AWBNO"));
		if("InsertIntoHistory".equals(controlName))
		{
			try {
				DBS.mLogger.debug("Reject Reasons Grid Length is "+data);

				String rejectReasonWithCode="";
				String strRejectReasons="";
				String strRejectCodes = "";
				if(Integer.parseInt(data)>0){
					rejectReasonWithCode=rejectReason(iformObj,data);
					String temp[]=rejectReasonWithCode.split("~");
					strRejectReasons=temp[0];
					strRejectCodes=temp[1];
				}
				
				DBS.mLogger.debug("Final reject reasons are "+strRejectReasons);
				JSONArray jsonArray=new JSONArray();
				JSONObject obj=new JSONObject();
				Calendar cal = Calendar.getInstance();			   
			    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			    String strDate = sdf.format(cal.getTime());
			    
				obj.put("Date Time",strDate);
				obj.put("Workstep",iformObj.getActivityName());
				obj.put("User Name", iformObj.getUserName());
				obj.put("Decision",iformObj.getValue("ID_DECISION"));
				obj.put("Reject Reasons", strRejectReasons);
				obj.put("Reject Reason Codes", strRejectCodes);
				obj.put("Remarks", iformObj.getValue("ID_REMARKS"));
				
				iformObj.setValue("DECISION", (String)iformObj.getValue("ID_DECISION"));
				//iformObj.setValue("AWBNO", (String)iformObj.getValue( (String)iformObj.getValue("SERVICE_REQ_CODE")+"_AWBNO"));
				DBS.mLogger.debug("Decision" +iformObj.getValue("ID_DECISION"));
				
				if("Initiation".equalsIgnoreCase(iformObj.getActivityName()))
					obj.put("Entry Date Time",iformObj.getValue("CreatedDateTime"));
				else
					obj.put("Entry Date Time",iformObj.getValue("EntryDateTime"));
				
				DBS.mLogger.debug("Entry Date Time : "+obj.get("Entry Date Time"));
				jsonArray.add(obj);
				iformObj.addDataToGrid("Q_USR_0_DBS_WIHISTORY", jsonArray);
				
				DBS.mLogger.debug("jsonArray : "+jsonArray);
			
				strReturn = "INSERTED";
				
				DBS.mLogger.debug("WINAME: "+getWorkitemName(iformObj)+", WSNAME: "+iformObj.getActivityName()+", ControlName: "+controlName+", WI Histroy Added Successfully!");
				
			} 
			catch (Exception e) {
				DBS.mLogger.debug("Exception in inserting WI History!" + e.getMessage());
			}
		
		}
		else if("setChargeCollection".equalsIgnoreCase(controlName)){
			String chargeCollectionInfo=getAccountDetail(iformObj,WI_Name);
			String []values=chargeCollectionInfo.split("#");
			String acctNo=values[0];
			String acctType=values[1];
			String currency=values[2];
			
			iformObj.setValue("CC_ACCOUNTNO",acctNo);
			iformObj.setValue("CC_ACCTTYPE",acctType);
			iformObj.setValue("CC_CURRENCY",currency);
			
			strReturn = "INSERTED";
		}
		else if("setValues".equalsIgnoreCase(controlName)){
			
			iformObj.setValue("IS_CHARGE_COLLECTED","NA");
			iformObj.setValue("IS_COURIER_CHARGED","NA");
			strReturn = "INSERTED";
		}
		else if("NotifyCall".equals(controlName))
		{
			strReturn=new DBS_NotifyCall().NotifyCall(iformObj,"");
		}
		else if("comms_trigger".equalsIgnoreCase(controlName)){
			return new DBS_InfobipIntegration().commsTrigger(iformObj, controlName, data);
			
		}
		DBS.mLogger.debug("WINAME: "+WI_Name+", WSNAME: "+activityName+", ControlName: "+controlName+", Returning");
		return strReturn;
	}
	public String rejectReason(IFormReference iformObj, String rejectReasonSize){
		DBS.mLogger.debug("Reject Reasons Grid Length is "+rejectReasonSize);
		String strRejectReasons="";
		String strRejectCodes = "";
		String strRejWithCode="";
		for(int p=0;p<Integer.parseInt(rejectReasonSize);p++)
		{	
			String completeReason = null;
			completeReason = iformObj.getTableCellValue("REJECT_REASON_GRID", p, 0);
			DBS.mLogger.debug("WINAME: "+getWorkitemName(iformObj)+", WSNAME: "+iformObj.getActivityName()+", Complete Reject Reasons" + completeReason);
			
			if (strRejectReasons == "")
			{						
				if(completeReason.indexOf("-")>-1)
				{
					strRejectCodes=completeReason.substring(0,completeReason.indexOf("-")).replace("(", "").replace(")", "");
					DBS.mLogger.debug("WINAME: "+getWorkitemName(iformObj)+", WSNAME: "+iformObj.getActivityName()+", Reject Reasons code" + strRejectCodes);
					strRejectReasons=completeReason.substring(completeReason.indexOf("-")+1);
					DBS.mLogger.debug("WINAME: "+getWorkitemName(iformObj)+", WSNAME: "+iformObj.getActivityName()+", Reject Reasons" + strRejectReasons);
				}
				else
				{
					strRejectReasons=completeReason;
					DBS.mLogger.debug("WINAME: "+getWorkitemName(iformObj)+", WSNAME: "+iformObj.getActivityName()+",Reject Reasons else block" + strRejectReasons);
				}
			}	
			else
			{
				DBS.mLogger.debug("WINAME: "+getWorkitemName(iformObj)+", WSNAME: "+iformObj.getActivityName()+",Reject Reasons 1" + strRejectReasons);						
				if(completeReason.indexOf("-")>-1)
				{
					strRejectCodes=strRejectCodes+"#"+completeReason.substring(0,completeReason.indexOf("-")).replace("(", "").replace(")", "");
					DBS.mLogger.debug("WINAME: "+getWorkitemName(iformObj)+", WSNAME: "+iformObj.getActivityName()+", Reject Reasons code" + strRejectCodes);
					strRejectReasons=strRejectReasons+"#"+completeReason.substring(completeReason.indexOf("-")+1);
					DBS.mLogger.debug("WINAME: "+getWorkitemName(iformObj)+", WSNAME: "+iformObj.getActivityName()+", Reject Reasons" + strRejectReasons);
				}
				else
				{
					strRejectReasons=strRejectReasons+"#"+completeReason;
					DBS.mLogger.debug("WINAME: "+getWorkitemName(iformObj)+", WSNAME: "+iformObj.getActivityName()+", Reject Reasons else block2" + strRejectReasons);
				}
				
				DBS.mLogger.debug("WINAME: "+getWorkitemName(iformObj)+", WSNAME: "+iformObj.getActivityName()+", Reject Reasons 2" + strRejectReasons);
			}
			
		}
		strRejWithCode=strRejectReasons+"~"+strRejectCodes;
		DBS.mLogger.debug("Final reject reasons are "+strRejectReasons);
		return strRejWithCode;
	}
	String getAccountDetail(IFormReference iformObj, String workItemName) {
		String accountNO ="";    
		String accttype ="";
		String currency =""; 
    	try {
    		// SQL injection vulnerability - using proper escaping
    		String escapedWorkItemName = workItemName.replace("'", "''"); // Escape single quotes
    		String strInputQry1="SELECT top 1 ACCOUNTNO,ACCTTYPE,CURRENCY FROM USR_0_DBS_005_ACCT_DTLS_FOR_CHARGE WITH(NOLOCK) WHERE WINAME='" + escapedWorkItemName + "' and COLLECTCHARGE='true'";			
    		
    		List<List<String>> dataFromDB = iformObj.getDataFromDB(strInputQry1);
    		
    		for (List<String> tableFrmDB : dataFromDB) {
    			accountNO = tableFrmDB.get(0).trim();
    			accttype=tableFrmDB.get(1).trim();
    			currency=tableFrmDB.get(2).trim();
    		}
    	} catch (Exception e) {
    		DBS.mLogger.error("Error fetching account details", e);
    	}
    	
    	return accountNO+"#"+accttype+"#"+currency;
    }

}
