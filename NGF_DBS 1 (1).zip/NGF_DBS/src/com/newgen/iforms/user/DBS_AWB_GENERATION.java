package com.newgen.iforms.user;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import com.newgen.iforms.custom.IFormReference;

public class DBS_AWB_GENERATION extends DBSCommon{
	public String generateAWB(IFormReference iformObj,String StringData)
	{
		String MQ_response="";
		String AWBNo="";
		String AWBgeneratedLink="";
	 	DBS.mLogger.debug("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", inside AWB call");
	 	try
	 	{
	 		MQ_response = new DBS_Integration().MQ_connection_response(iformObj,"AWB_GENERATION",StringData);
	 		MQ_response=MQ_response.substring(MQ_response.indexOf("<?xml v"),MQ_response.indexOf("</MQ_RESPONSE_XML>"));
	 		DBS.mLogger.debug("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", inside AWB call"+MQ_response);
			String ReturnCode1 = "";
			if(MQ_response.indexOf("<ReturnCode>")!=-1)
			{
				ReturnCode1 = MQ_response.substring(MQ_response.indexOf("<ReturnCode>")+"</ReturnCode>".length()-1,MQ_response.indexOf("</ReturnCode>"));
			}
			String ReturnDesc = "";
			if(MQ_response.indexOf("<ReturnDesc>")!=-1)
			{
				ReturnDesc = MQ_response.substring(MQ_response.indexOf("<ReturnDesc>")+"</ReturnDesc>".length()-1,MQ_response.indexOf("</ReturnDesc>"));
			}

			DBS.mLogger.debug("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", Return  code for the AUTHORISED SIGNATORY  call: "+ReturnCode1);
			if(ReturnCode1.equals("0000"))
			{

				if (MQ_response.contains("<AWBGenerationResponse>"))
				{
					AWBNo = MQ_response.substring(MQ_response.indexOf("<AWBNumber>")+"</AWBNumber>".length()-1,MQ_response.indexOf("</AWBNumber>"));
					AWBgeneratedLink = MQ_response.substring(MQ_response.indexOf("<AWBPdf>")+"</AWBPdf>".length()-1,MQ_response.indexOf("</AWBPdf>"));
					
				}
				DBS.mLogger.debug("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", Return  code for the AWB call: "+ReturnCode1);
				iformObj.setValue("AWBNO",AWBNo);
				iformObj.setValue("AWB_PDF_LINK",AWBgeneratedLink);
				iformObj.setValue("IS_AWB_GENERATED","Y");
				//Data used in Report//
				Calendar cal = Calendar.getInstance();			   
			    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			    String strDate = sdf.format(cal.getTime());
				iformObj.setValue("AWB_GEN_DATE",strDate);
				DBS.mLogger.debug("AWB_GEN_DATE:"+strDate);
				/*******************/
				return "Success";
			}
			else
			{
				iformObj.setValue("IS_AWB_GENERATED","N");
				return "Failure";
			}
	 		
	 	}
	 	catch(Exception e)
	 	{
	 		DBS.mLogger.debug("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", Exception in AWB call:");
	 		return "Error in AWB Generation Integration Call.";
	 	}
		
	}

}
