package com.newgen.iforms.user;

import java.util.List;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.newgen.iforms.custom.IFormReference;

public class DBS_onFocus extends DBSCommon {

	private static final String EXCEPTION_OCCURED = null;
	private static final String UNHANDLED = null;
	private static final String SUCCESS = null;
	private static final String FAIL = null;
	private String WI_Name = null;
	private String actName = null;
	private String userName = null;
	private String inputString = null;
	private IFormReference giformObj = null;

	public String onFocus(IFormReference iformObj, String control, String stringdata) {
		DBS.mLogger.info("Inside onChange method of DBO_onFocus with control id-- " + control);
		WI_Name = getWorkitemName(iformObj);
		actName = iformObj.getActivityName();
		userName = iformObj.getUserName();
		inputString = stringdata;
		giformObj = iformObj;
		String decision =  (String) iformObj.getValue("DECISION");

		try {
			DBS.mLogger.debug("value of control inside focus event before if condition " + control);
		
		} catch (Exception exc) {
			DBS.printException(exc);
			DBS.mLogger.debug("Exception 2 - " + exc);
		}

		return UNHANDLED;
	}

}
