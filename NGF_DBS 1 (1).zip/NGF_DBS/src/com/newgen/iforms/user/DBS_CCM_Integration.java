package com.newgen.iforms.user;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Base64;
import java.util.List;
import java.util.Locale;

import javax.json.Json;
import javax.json.JsonObject;
import javax.net.ssl.HttpsURLConnection;

import org.json.JSONArray;
import org.json.JSONObject;

import com.newgen.iforms.custom.IFormReference;

public class DBS_CCM_Integration {
	
	
	// Constants for better maintainability
	private static final String UTF_8_ENCODING = "utf-8";
	private static final String CONTENT_TYPE_JSON = "application/json";
	private static final String DATE_FORMAT = "dd/MM/yyyy";
	private static final String SOURCE_DATE_FORMAT = "yyyy-MM-dd";
	
	public String requestResponseCCMJSON(IFormReference iformObj)
    {
		try{
			// Input validation
			if (iformObj == null) {
				DBS.mLogger.error("IFormReference object is null");
				return "Failure in PDF generation - Invalid input";
			}
			
			String workItemName = (String) iformObj.getValue("WorkItemName");
			if (workItemName == null || workItemName.trim().isEmpty()) {
				DBS.mLogger.error("WorkItemName is null or empty");
				return "Failure in PDF generation - Missing WorkItem";
			}
			
		String endPointUrl = DBS.properties.getProperty("ENDPOINTURL");
		String documentPath = DBS.properties.getProperty("DOCUMENT_PATH");
		String wfd_Path = DBS.properties.getProperty((String)iformObj.getValue("SERVICE_REQ_CODE")+"_WFD_PATH");
		Locale locale = new Locale("ar", "AE");
		// Get account details for the request

		// Get service request code to determine JSON structure
		String serviceReqCode = (String) iformObj.getValue("SERVICE_REQ_CODE");
		
		// Create service-specific CACT object
		org.json.JSONObject cactObject = null;
		
		if("DBS003".equalsIgnoreCase(serviceReqCode)) {
			// Balance Confirmation Letter JSON structure
			org.json.JSONArray listArray = getAccountDetailsArray(iformObj, workItemName);
			cactObject = new org.json.JSONObject()
				.put("addresseeName", iformObj.getValue("LETTERRECIPIENT"))
				.put("addressLine1", iformObj.getValue("ADDRESSLINE1"))
				.put("addressLine2", iformObj.getValue("ADDRESSLINE2"))
				.put("emirate", iformObj.getValue("EMIRATES"))
				.put("country", iformObj.getValue("COUNTRY"))
				.put("dateIssued", DBSCommon.getCurrentDate(DATE_FORMAT))
				.put("referenceNumber", iformObj.getValue("DBREFERENCENO"))
				.put("companyName", iformObj.getValue("COMPANYNAME"))
				.put("IsAllProdIncluded", iformObj.getValue("ISALLPRODINCLUDED"))
				.put("balanceConfirmAsOf", new DBSCommon().convertDateFormat((String)iformObj.getValue("BAL_CONFIRMED_ASOF"),SOURCE_DATE_FORMAT,DATE_FORMAT,iformObj,locale))
				.put("list", listArray)
				.put("deliveryMethod", "Physical");
		}
		else if("DBS005".equalsIgnoreCase(serviceReqCode)) {
			// payment management service request pdf JSON structure 
			//String DebitAcctNo=new DBS_Integration().getAccountDetail(iformObj, workItemName);
			cactObject = new org.json.JSONObject()
				.put("businessName", iformObj.getValue("COMPANYNAME"))
				.put("addressLine1", iformObj.getValue("ADDRESSLINE1"))
				.put("addressLine2", iformObj.getValue("ADDRESSLINE2"))
				.put("poBox", iformObj.getValue("EMIRATES")) //pobox
				.put("country", iformObj.getValue("COUNTRY"))
				.put("dateIssued", DBSCommon.getCurrentDate(DATE_FORMAT))
				.put("accountNumber",iformObj.getValue("CC_ACCOUNTNO"))
				.put("paymentServiceType", iformObj.getValue("REQ_TYPE"))
				.put("paymentInfoRemarks", iformObj.getValue("SWIFT_COPY"));
		}
       DBS.mLogger.info("Inside requestResponseJSON method-cactObject: "+cactObject);
       
        org.json.JSONArray cactArray = new org.json.JSONArray();
        cactArray.put(cactObject);

        // Create the final JSON object
        org.json.JSONObject request = new org.json.JSONObject()
            .put("CACT", cactArray);
      //  DBS.mLogger.info("Inside requestResponseJSON method-request: "+request);
        // Convert the JSON object to a string
        String jsonString = request.toString();

        // Encode the JSON string to Base64
        String base64Encoded_request = Base64.getEncoder().encodeToString(jsonString.getBytes());

        // Print the Base64-encoded string
       // DBS.mLogger.info("Base64 Encoded JSON: " + base64Encoded_request);

        String final_request="";
        final_request=FinalJsonRequest(base64Encoded_request,wfd_Path);
        DBS.mLogger.info("Base64 Encoded JSON final_request: " + final_request);
        URL url = new URL(endPointUrl);
        DBS.mLogger.info("URL After: " + url);
        HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
        DBS.mLogger.info("After http connection");
        connection.setRequestMethod("POST");
        connection.setDoOutput(true);
        connection.setRequestProperty("Content-Type", CONTENT_TYPE_JSON);

        // Prepare the POST data (assuming JSON payload here)
        
        // Send POST data
       try (OutputStream os = connection.getOutputStream()) {
            byte[] input = final_request.getBytes(UTF_8_ENCODING);
            os.write(input);
            os.flush();
        }

        // Get response code
        int responseCode = connection.getResponseCode();
        if (responseCode == HttpURLConnection.HTTP_OK) {
            // Read the response
        
            try (InputStream inputStream = connection.getInputStream();
                 BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream))) {

                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                DBS.mLogger.info("Starting pdf generation");
                // Service-specific PDF naming
                String pdfName = "";
                if("DBS003".equalsIgnoreCase(serviceReqCode)) {
                	pdfName = "Balance_Confirmation_Letter";
                } 
                else if("DBS005".equalsIgnoreCase(serviceReqCode)) {
                	pdfName = "SWIFT_Copy";
                }
    			String WorkItemName = String.valueOf(iformObj.getValue("WorkItemName"));
    			String dynamicPdfName=WorkItemName +"_"+ pdfName + ".pdf";
                // Extract Base64 encoded PDF data
    			String base64PdfData="";
    			DBS.mLogger.info("CCM Response received");
    			DBS.mLogger.info("CCM Response "+response.toString());
    			try {
    				JSONObject jsonObject=new JSONObject(response.toString());
    				if (!jsonObject.has("source")) {
    					DBS.mLogger.error("CCM Response missing 'source' field");
    					return "Failure in PDF generation - Invalid response format";
    				}
    				
    				JSONArray sourceArray=jsonObject.getJSONArray("source");
    				if (sourceArray.length() == 0) {
    					DBS.mLogger.error("CCM Response has empty source array");
    					return "Failure in PDF generation - Empty response";
    				}
    				
    				JSONObject firstSourceobject=sourceArray.getJSONObject(0);
    				if (!firstSourceobject.has("Item")) {
    					DBS.mLogger.error("CCM Response missing 'Item' field in source");
    					return "Failure in PDF generation - Missing PDF data";
    				}
    				
    				base64PdfData=firstSourceobject.getString("Item");
    				if (base64PdfData == null || base64PdfData.trim().isEmpty()) {
    					DBS.mLogger.error("CCM Response has empty PDF data");
    					return "Failure in PDF generation - Empty PDF data";
    				}
    			} catch (Exception jsonEx) {
    				DBS.mLogger.error("Failed to parse CCM response JSON", jsonEx);
    				return "Failure in PDF generation - Invalid JSON response";
    			}
                //String base64PdfData = response.toString();
               // DBS.mLogger.info("pdf generation"+base64PdfData);
                // Decode Base64 data to bytes
                byte[] pdfBytes = Base64.getDecoder().decode(base64PdfData);
                DBS.mLogger.info("byte generation"+pdfBytes);
                // Save PDF bytes to file with proper resource management
                String tempDir1 = System.getProperty("user.dir");
                String fullPath=tempDir1+documentPath+dynamicPdfName;
                DBS.mLogger.info("file path: " + fullPath);
                
                try (FileOutputStream fos = new FileOutputStream(fullPath)) {
                    fos.write(pdfBytes);
                }
                String attachedPDFresponse = new DBSCommon().AttachDocumentWithWI(iformObj,WorkItemName,dynamicPdfName,pdfName);
    			//DBS.mLogger.info(" Printed response---->>"+attachedPDFresponse);
    			if(attachedPDFresponse.contains("0000"))
    			{
    				DBSCommon.DeleteFile(fullPath);
    			}
    			 return attachedPDFresponse;
            }
        } 
        else {
            DBS.mLogger.error("CCM POST request failed. Response Code: " + responseCode);
            try (InputStream errorStream = connection.getErrorStream()) {
                if (errorStream != null) {
                    try (BufferedReader errorReader = new BufferedReader(new InputStreamReader(errorStream))) {
                        StringBuilder errorResponse = new StringBuilder();
                        String line;
                        while ((line = errorReader.readLine()) != null) {
                            errorResponse.append(line);
                        }
                        DBS.mLogger.error("Error response: " + errorResponse.toString());
                    }
                }
            } catch (Exception errorEx) {
                DBS.mLogger.error("Failed to read error response", errorEx);
            }
            return "Failure in PDF generation - HTTP " + responseCode;
        }

		}
		catch(Exception e)
		{
			 DBS.mLogger.error("CCM Integration exception occurred", e);
			 return "Failure in PDF generation - " + e.getMessage();
		}
    }
  
    public String FinalJsonRequest(String base64Encoded_request,String templatePath)
    {
    	JsonObject ccm_jsonRequest = Json.createObjectBuilder()
          		.add("command", Json.createArrayBuilder()
          				.add(Json.createObjectBuilder().add("CommandName", "-e")
          						.add("commandValue", "PDF")))
          		.add("dataDefinition", Json.createArrayBuilder()
          				.add(Json.createObjectBuilder()
          						.add("ModuleName", "JSONDataInput1")
          				.add("item", base64Encoded_request)
          				.add("itemType", "Base64")))
          		.add("workFlowDefinition",templatePath )
          		.add("responnseType", 0)
          		.add("logLevel", "Info")
					.build();
    	return ccm_jsonRequest.toString();
    }
    
    private org.json.JSONArray getAccountDetailsArray(IFormReference iformObj, String workItemName) {
    	org.json.JSONArray listArray = new org.json.JSONArray();
    	
    	try {
    		// SQL injection vulnerability - using proper escaping
    		String escapedWorkItemName = workItemName.replace("'", "''"); // Escape single quotes
    		String strInputQry1="SELECT ACCOUNTNO,ACCOUNTTYPE,CURRENCY,BALANCE FROM USR_0_DBS_003_ACCT_DTLS WITH(NOLOCK) WHERE WINAME='" + escapedWorkItemName + "'";			
    		
    		List<List<String>> dataFromDB = iformObj.getDataFromDB(strInputQry1);
    		
    		for (List<String> tableFrmDB : dataFromDB) {
    			String accountNO = tableFrmDB.get(0).trim();
    			String ibanNo = tableFrmDB.get(1).trim(); //accountDescription
    			String currency = tableFrmDB.get(2).trim();
    			String balance = tableFrmDB.get(3).trim();
    			String formatted_bal = "";
    			
    			if(balance != null && !balance.trim().isEmpty()){
    				try {
    					Double formatted_balance = Double.parseDouble(balance.trim());
    					DecimalFormat numberFormat = (DecimalFormat) NumberFormat.getNumberInstance(Locale.US);
    					numberFormat.applyPattern("#,##0.00");
    					formatted_bal = numberFormat.format(formatted_balance);
    				} catch (NumberFormatException e) {
    					DBS.mLogger.warn("Invalid balance format for account " + accountNO + ": " + balance);
    					formatted_bal = "0.00";
    				}
    			} else {
    				formatted_bal = "0.00";
    			}
    			
    			listArray.put(new org.json.JSONObject()
    				.put("accountDescription", ibanNo)
    				.put("accountNumber", accountNO)
    				.put("currency", currency)
    				.put("balance", formatted_bal));
    		}
    	} catch (Exception e) {
    		DBS.mLogger.error("Error fetching account details", e);
    	}
    	
    	return listArray;
    }
    
}
