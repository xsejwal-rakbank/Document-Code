package com.newgen.iforms.user;

import java.io.DataInputStream;
import java.io.DataOutputStream;

import java.io.InputStream;
import java.io.OutputStream;

import java.net.Socket;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import java.util.List;
import java.util.Locale;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;



import com.newgen.iforms.custom.IFormReference;
import com.newgen.mvcbeans.model.wfobjects.WDGeneralData;

public class DBS_Integration extends DBSCommon {
	
	String customerName="";
	String groupName="";
	String modeOfOperation="";

	public String collectCharge(IFormReference iformObj,String StringData)
	{
		String MQ_response="";
	 	DBS.mLogger.debug("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", inside Collection Charge call");
	 	try
	 	{
	 		MQ_response = MQ_connection_response(iformObj,"COLLECTCHARGE",StringData);
			
			if(MQ_response.contains("Not Sufficient funds"))
			{
				return "Not Sufficient funds";
			}
			else
			{
				MQ_response=MQ_response.substring(MQ_response.indexOf("<?xml v"),MQ_response.indexOf("</MQ_RESPONSE_XML>"));
				
				String ReturnCode1 = "";
				if(MQ_response.indexOf("<ReturnCode>")!=-1)
				{
					ReturnCode1 = MQ_response.substring(MQ_response.indexOf("<ReturnCode>")+"</ReturnCode>".length()-1,MQ_response.indexOf("</ReturnCode>"));
				}
				String ReturnDesc = "";
				if(MQ_response.indexOf("<ReturnDesc>")!=-1)
				{
					ReturnDesc = MQ_response.substring(MQ_response.indexOf("<ReturnDesc>")+"</ReturnDesc>".length()-1,MQ_response.indexOf("</ReturnDesc>"));
				}
				
				DBS.mLogger.debug("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", Return  code for the Charge Collection call: "+ReturnCode1);
				if(ReturnCode1.equals("0000"))
				{
					DBS.mLogger.debug("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", @@@@@@@@@@ : Successful charge collected");
					if(ReturnDesc.contains("Success")){
						ReturnDesc="Success";
					}
					if("SERVICE_CHARGE".equalsIgnoreCase(StringData)){
						iformObj.setValue("IS_CHARGE_COLLECTED","Y");
						DBS.mLogger.debug("IS_CHARGE_COLLECTED :Y");
					}
					else if("COURIER_CHARGE".equalsIgnoreCase(StringData)){
						iformObj.setValue("IS_COURIER_CHARGED","Y");
					}
					else if("CORRESPONDED_CHARGE".equalsIgnoreCase(StringData)){
						iformObj.setValue("IS_COURIER_CHARGED","Y"); //IS_COURIER_CHARGED is being used to keep status of corresponded charge status
					}
					return ReturnDesc;
				}	
				else
				{
					DBS.mLogger.debug("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", Error in Response of Collect call "+ReturnCode1+" ~ "+ReturnDesc);
					return ReturnDesc;									
				}
			}
	 	}
	 	catch(Exception e)
	 	{
	 		DBS.mLogger.debug("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", Exception in Collect call:");
	 		return "Error in Collection Charge Integration Call.";
	 	}
		
	}
	private static String getMQInputXML(String sessionID, String cabinetName,
			String wi_name, String ws_name, String userName,
			StringBuilder final_xml) {
		DBS.mLogger.debug("inside getMQInputXML function");
		StringBuffer strBuff = new StringBuffer();
		strBuff.append("<APMQPUTGET_Input>");
		strBuff.append("<SessionId>" + sessionID + "</SessionId>");
		strBuff.append("<EngineName>" + cabinetName + "</EngineName>");
		strBuff.append("<XMLHISTORY_TABLENAME>NG_DBS_XMLLOG_HISTORY</XMLHISTORY_TABLENAME>");
		strBuff.append("<WI_NAME>" + wi_name + "</WI_NAME>");
		strBuff.append("<WS_NAME>" + ws_name + "</WS_NAME>");
		strBuff.append("<USER_NAME>" + userName + "</USER_NAME>");
		strBuff.append("<MQ_REQUEST_XML>");
		strBuff.append(final_xml);
		strBuff.append("</MQ_REQUEST_XML>");
		strBuff.append("</APMQPUTGET_Input>");
		return strBuff.toString();
		
	}
	public String getOutWtthMessageID(String callName,IFormReference iformObj,String message_ID){
		String outputxml="";
		try{
			String wi_name = getWorkitemName(iformObj);
			String str_query = "select OUTPUT_XML from NG_DBS_XMLLOG_HISTORY with (nolock) where CALLNAME ='"+callName+"' and MESSAGE_ID ='"+message_ID+"' and WI_NAME = '"+wi_name+"'";
			List<List<String>> result=iformObj.getDataFromDB(str_query);
			
			DBS.mLogger.debug("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+". Data for result is below as length: " + result.size());
			for(List<String> x : result)
				DBS.mLogger.debug("x: " + x.toString());
						
			String Integration_timeOut="100";
			int Loop_wait_count=10;
			try
			{
				Loop_wait_count=Integer.parseInt(Integration_timeOut);
			}
			catch(Exception ex)
			{
				Loop_wait_count=10;
			}
		
			for(int Loop_count=0;Loop_count<Loop_wait_count;Loop_count++){
				if(result.size()>0){
					outputxml = result.get(0).get(0);
					break;
				}
				else{
					Thread.sleep(1000);
					result=iformObj.getDataFromDB(str_query);
				}
			}
			
			if("".equalsIgnoreCase(outputxml)){
				outputxml="Error";
			}
			String outputxmlMasked = outputxml;
			outputxmlMasked = maskXmlogBasedOnCallType(outputxmlMasked,callName,iformObj);
			outputxmlMasked=maskXmlTags(outputxmlMasked,"USERNAME",iformObj);
			
			DBS.mLogger.debug("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", getOutWtthMessageID: " + outputxmlMasked); // error				
		}
		catch(Exception e){
			DBS.mLogger.debug("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", Exception occurred in getOutWtthMessageID" + e.getMessage());
			DBS.mLogger.debug("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", Exception occurred in getOutWtthMessageID" + e.getStackTrace());
			outputxml="Error";
		}
		return outputxml;
	}
	public String MQ_connection_response(IFormReference iformObj,String control,String Data)
	{

		
		DBS.mLogger.debug("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", Inside MQ_connection_response function");
		DBS.mLogger.debug("Check 12345. " + "control: " + control + " Data: " + Data);
		final WDGeneralData wdgeneralObj;	
		Socket socket = null;
		OutputStream out = null;
		InputStream socketInputStream = null;
		DataOutputStream dout = null;
		DataInputStream din = null;
		String mqOutputResponse = null;
		String mqInputRequest = null;
		String cabinetName = getCabinetName(iformObj);
		String wi_name = getWorkitemName(iformObj);
		String ws_name = getActivityName(iformObj);
		String sessionID = getSessionId(iformObj);
		String userName = getUserName(iformObj);
		String socketServerIP;
		int socketServerPort;
		wdgeneralObj = iformObj.getObjGeneralData();
		sessionID = wdgeneralObj.getM_strDMSSessionId();
		
		if(control.equalsIgnoreCase("COLLECTCHARGE"))
		{
			java.util.Date d1 = new Date();
			SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.mmm");
			String DateExtra2 = sdf1.format(d1)+"+04:00";
			String DebitAcctNo="";
			String chargeAmt="0";
			String eventId="";
			String eventType="";
			String serviceReq="";
			String balance="-1";
			String transactionType="";
			java.util.Date d2 = new Date();
			SimpleDateFormat sdf2 = new SimpleDateFormat("dd-MM-yyyy");
			String currDate = sdf2.format(d2);
			DebitAcctNo = (String) iformObj.getValue("CC_ACCOUNTNO");
			balance = (String) iformObj.getValue("CC_BALANCE");
			
			DBS.mLogger.debug("Account details"+DebitAcctNo+" "+balance);
			if("DBS002".equalsIgnoreCase((String)iformObj.getValue("SERVICE_REQ_CODE")))
			{
				eventType="Service";
			}
			if("DBS003".equalsIgnoreCase((String)iformObj.getValue("SERVICE_REQ_CODE")) && "SERVICE_CHARGE".equalsIgnoreCase(Data))
			{
				transactionType="BI";
				if("CBD".equalsIgnoreCase((String)iformObj.getValue("SEGMENT")))
				{
					if("185".equalsIgnoreCase((String)iformObj.getValue("SOLID")) || "926".equalsIgnoreCase((String)iformObj.getValue("SOLID"))){
						eventType="Service-CBD";
					}
					else{
						eventType="Service-WBG";
						DBS.mLogger.debug("IS courier charged"+iformObj.getValue("IS_COURIER_CHARGED"));
						iformObj.setValue("IS_COURIER_CHARGED","NA");
						DBS.mLogger.debug("IS courier charged after"+iformObj.getValue("IS_COURIER_CHARGED"));
					}
					
				}
				else if(((String)iformObj.getValue("CUSTOMERNAME")).equalsIgnoreCase((String)iformObj.getValue("LETTERRECIPIENT")))
				{
					eventType="Service-Self";
				}
				else
				{
					eventType="Service-Other";
				}
				String strInputQry4="select EVENT_ID from USR_0_DBS_SERVICE_CHARGE_MASTER  with(nolock) where ISACTIVE='Y' and service_req_code='"+(String)iformObj.getValue("SERVICE_REQ_CODE")+"' and event_type='"+eventType+"'";			
				List<List<String>> dataFromDB4 = iformObj.getDataFromDB(strInputQry4);
				for (List<String> tableFrmDB : dataFromDB4) {
					eventId = tableFrmDB.get(0).trim();
						}
				
			}
			else if("Courier".equalsIgnoreCase((String)iformObj.getValue("DELIVERYTYPE")) && "COURIER_CHARGE".equalsIgnoreCase(Data))
			{
				/*if(iformObj.getValue("SEGMENT")=="CBD" && (iformObj.getValue("SOLID")!="185" && iformObj.getValue("SOLID")!="926")){
					return "NA";
				}*/
				//eventId="BBG_COURIER_CHRGS";
				transactionType="CI";
				String strInputQry5="select CONST_FIELD_VALUE from USR_0_BPM_CONSTANTS with(nolock) where CONST_FIELD_NAME='DBS_CourierChargeEventId'";			
				
				List<List<String>> dataFromDB4 = iformObj.getDataFromDB(strInputQry5);
				for (List<String> tableFrmDB : dataFromDB4) {
					eventId = tableFrmDB.get(0).trim();
						}
			}
			
			/***************************************************start charge collection block for DBS005************************************************************************************/
			
			if("DBS005".equalsIgnoreCase((String)iformObj.getValue("SERVICE_REQ_CODE")))
			{
				
				//DebitAcctNo=getAccountDetail(iformObj, wi_name);
				if("SERVICE_CHARGE".equalsIgnoreCase(Data)){
					transactionType="BI";
					String segment = (String)iformObj.getValue("SEGMENT");
					
					// Dynamic event type derivation: Service-{SEGMENT}, with WBG exception for CBD
					if("CBD".equalsIgnoreCase(segment))
					{
						String solid = (String)iformObj.getValue("SOLID");
						// Static WBG for specific SOLID values, otherwise dynamic CBD
						eventType = ("185".equalsIgnoreCase(solid) || "926".equalsIgnoreCase(solid)) 
							? "Service-CBD" 
							: "Service-WBG";
					}
					else
					{
						// Dynamic derivation for other segments: Service-{SEGMENT}
						eventType = "Service-" + segment;
					}
					
					String strInputQry4="select EVENT_ID from USR_0_DBS_SERVICE_CHARGE_MASTER  with(nolock) where ISACTIVE='Y' and service_req_code='"+(String)iformObj.getValue("SERVICE_REQ_CODE")+"' and event_type='"+eventType+"'";			
					List<List<String>> dataFromDB4 = iformObj.getDataFromDB(strInputQry4);
					for (List<String> tableFrmDB : dataFromDB4) {
						eventId = tableFrmDB.get(0).trim();
							}
				}
				else if("CORRESPONDED_CHARGE".equalsIgnoreCase(Data))
				{
					transactionType="BI";
					String segment = (String)iformObj.getValue("SEGMENT");
					String currency = (String)iformObj.getValue("CC_CURRENCY");
					
					// Dynamic event type derivation: {SEGMENT}-Corresponded-{CC_CURRENCY}, with WBG exception for CBD
					if("CBD".equalsIgnoreCase(segment))
					{
						String solid = (String)iformObj.getValue("SOLID");
						// WBG for CBD segment except SOLID 185,926
						eventType = ("185".equalsIgnoreCase(solid) || "926".equalsIgnoreCase(solid)) 
							? segment + "-Corresponded-" + currency 
							: "WBG-Corresponded-" + currency;
					}
					else
					{
						// Dynamic derivation for other segments: {SEGMENT}-Corresponded-{CC_CURRENCY}
						eventType = segment + "-Corresponded-" + currency;
					}
					
					String strInputQry5="select EVENT_ID from USR_0_DBS_SERVICE_CHARGE_MASTER with(nolock) where ISACTIVE='Y' and service_req_code='"+(String)iformObj.getValue("SERVICE_REQ_CODE")+"' and event_type='"+eventType+"'";			
					List<List<String>> dataFromDB4 = iformObj.getDataFromDB(strInputQry5);
					for (List<String> tableFrmDB : dataFromDB4) {
						eventId = tableFrmDB.get(0).trim();
							}
				}
			}
			
			/******************************************************end charge collection block for DBS005********************************************************************************/
		
			StringBuilder CollectChargeInput=new StringBuilder(
							"<EE_EAI_MESSAGE>\n" +
								"<EE_EAI_HEADER>\n" +
									"<MsgFormat>CHARGE_COLLECTION</MsgFormat>\n" +
									"<MsgVersion>0001</MsgVersion>\n" +
									"<RequestorChannelId>BPM</RequestorChannelId>\n" +
									"<RequestorUserId>RAKUSER</RequestorUserId>\n" +
									"<RequestorLanguage>E</RequestorLanguage>\n" +
									"<RequestorSecurityInfo>secure</RequestorSecurityInfo>\n" +
									"<ReturnCode>911</ReturnCode>\n" +
									"<ReturnDesc>Issuer Timed Out</ReturnDesc>\n" +
									"<MessageId>123123453</MessageId>\n" +
									"<Extra1>REQ||SHELL.JOHN</Extra1>\n" +
									"<Extra2>"+DateExtra2+"</Extra2>\n" +
								"</EE_EAI_HEADER>\n" +
								"<ProcessChargeCollectionRequest>\n" +
									"<DebitAcct>"+DebitAcctNo+"</DebitAcct>\n" +
									"<EventId>"+eventId+"</EventId>\n" + //"+eventId+" 
								/*	"<ChargeAmt></ChargeAmt>\n" +*/
									"<TransactionType>"+transactionType+"</TransactionType>\n" +
									"<CurCode>AED</CurCode>\n" +
									"<ValueDate>"+currDate+"</ValueDate>\n" +
								"</ProcessChargeCollectionRequest>\n" +
							"</EE_EAI_MESSAGE>");	
			
			mqInputRequest = getMQInputXML(sessionID, cabinetName,wi_name, ws_name, userName, CollectChargeInput);
			String InputxmlMasked = mqInputRequest;
			InputxmlMasked = maskXmlogBasedOnCallType(InputxmlMasked,"COLLECTCHARGE",iformObj);
			DBS.mLogger.debug("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", mqInputRequest for Collect Charge" + InputxmlMasked);
			
		}
		else if(control.equalsIgnoreCase("AWB_GENERATION"))
		{
			java.util.Date d1 = new Date();
			SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.mmm");
			String DateExtra2 = sdf1.format(d1)+"+04:00";
			String companyName="";
			String address="";
			String city="";
			String country="";
			String contactPerson="";
			String mobNo="";
			String courierMobNo="";
			
			String cifid=((String)iformObj.getValue("CIFID"));
		
			companyName=((String)iformObj.getValue("COMPANYNAME"));
			address=((String)iformObj.getValue("CD_ADDRESSLINE1")+" "+(String)iformObj.getValue("CD_ADDRESSLINE2"));
			city=((String)iformObj.getValue("CD_CITY"));
			country=((String)iformObj.getValue("CD_COUNTRY"));
			contactPerson=((String)iformObj.getValue("CD_CONTACT_PERSON"));
			//mobNo=((String)iformObj.getValue("MOBNO"));
			courierMobNo=((String)iformObj.getValue("CD_CONTACT_NO"));
			
			StringBuilder AWBInputXML=new StringBuilder("<EE_EAI_MESSAGE>"+
					   "<EE_EAI_HEADER>"+
					      "<MsgFormat>AWB_GENERATION</MsgFormat>"+
					      "<MsgVersion>0001</MsgVersion>"+
					      "<RequestorChannelId>CAS</RequestorChannelId>"+
					      "<RequestorUserId>RAKUSER</RequestorUserId>"+
					      "<RequestorLanguage>E</RequestorLanguage>"+
					      "<RequestorSecurityInfo>secure</RequestorSecurityInfo>"+
					      "<ReturnCode>0000</ReturnCode>"+
					      "<ReturnDesc>REQ</ReturnDesc>"+
					      "<MessageId>CA179811c23</MessageId>"+
					      "<Extra1>REQ||BPM.123</Extra1>"+
					      "<Extra2>"+DateExtra2+"</Extra2>"+
					   "</EE_EAI_HEADER>"+
					   "<AWBGenerationRequest>"+
					      "<ToCompany>"+contactPerson+"</ToCompany>"+//companyName
					      "<ToAddress>"+address+"</ToAddress>"+
					      "<ToLocation>"+city+"</ToLocation>"+
					      "<ToCountry>"+country+"</ToCountry>"+
					      "<ToCperson>"+contactPerson+"</ToCperson>"+
					      "<ToContactno>"+courierMobNo+"</ToContactno>"+
					      "<ToMobileno>"+courierMobNo+"</ToMobileno>"+
					      "<ReferenceNumber>"+wi_name+"</ReferenceNumber>"+
					      "<Weight>1.0</Weight>"+
					      "<Pieces>1</Pieces>"+
					      "<PackageType>Document</PackageType>"+
					      "<CurrencyCode>AED</CurrencyCode>"+
					      "<NcndAmount>0.0</NcndAmount>"+
					      "<ItemDescription>"+cifid+"</ItemDescription>"+
					      "<SpecialInstruction></SpecialInstruction>"+
					      "<ProductType>0</ProductType>"+
					      "<BranchName>Dubai</BranchName>"+
					   "</AWBGenerationRequest>"+
					"</EE_EAI_MESSAGE>");	
			
			mqInputRequest = getMQInputXML(sessionID, cabinetName,wi_name, ws_name, userName, AWBInputXML);
			String InputxmlMasked = mqInputRequest;
			InputxmlMasked = maskXmlogBasedOnCallType(InputxmlMasked,"AWB_GENERATION",iformObj);
			DBS.mLogger.debug("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", mqInputRequest for Collect Charge" + InputxmlMasked);
			
		}
		else if(control.equalsIgnoreCase("NotifyCall"))
		{
			java.util.Date d1 = new Date();
			SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.mmm");
			String DateExtra2 = sdf1.format(d1)+"+04:00";
			
			String prospectId=((String)iformObj.getValue("DBREFERENCENO"));
			String wiStatus="";
			String rejectReasonTag="";
			if("Approve".equalsIgnoreCase((String)iformObj.getValue("ID_DECISION")) || "Submit".equalsIgnoreCase((String)iformObj.getValue("ID_DECISION"))){
				
				wiStatus="SUC";
			}
			else if("Reject".equalsIgnoreCase((String)iformObj.getValue("ID_DECISION"))){
				
				wiStatus="REJ";
				String rejcetReasonWithcode[]=new DBS_IntroDone().rejectReason(iformObj,Integer.toString(iformObj.getDataFromGrid("REJECT_REASON_GRID").size())).split("~");
				String reasons="";
				reasons=rejcetReasonWithcode[0];
				
				rejectReasonTag="<FAILURE_REASON>"+reasons+"</FAILURE_REASON>";
			}
			
			StringBuilder NotifyInputXML=new StringBuilder("<EE_EAI_MESSAGE>\n" +
				    "    <EE_EAI_HEADER>\n" +
				    "        <MsgFormat>NOTIFY_BBG_APPLICATION</MsgFormat>\n" +
				    "        <MsgVersion>0001</MsgVersion>\n" +
				    "        <RequestorChannelId>BPM</RequestorChannelId>\n" +
				    "        <RequestorUserId>RAKUSER</RequestorUserId>\n" +
				    "        <RequestorLanguage>E</RequestorLanguage>\n" +
				    "        <RequestorSecurityInfo>secure</RequestorSecurityInfo>\n" +
				    "        <ReturnCode>911</ReturnCode>\n" +
				    "        <ReturnDesc>Issuer Timed Out</ReturnDesc>\n" +
				    "        <MessageId>NOTIFY_BBG_APPLICATION_11134</MessageId>\n" +
				    "        <Extra1>REQ||SHELL.JOHN</Extra1>\n" +
				    "        <Extra2>"+DateExtra2+"</Extra2>\n" +
				    "    </EE_EAI_HEADER>\n" +
				    "    <NotifyBBGApplicationStatusRequest>\n" +
				    "        <BankId>RAK</BankId>\n" +
				    "        <Process_Name>DBS</Process_Name>\n" +
				    "        <ProspectId>"+prospectId+"</ProspectId>\n" +
				    "        <ChannelId>EBC.INB</ChannelId>\n" +
				    "        <WorkitemNumber>"+wi_name+"</WorkitemNumber>\n" +
				    "        <Event>WI_STATUS</Event>\n" +
				    "       <WorkItemStatus>"+wiStatus+"</WorkItemStatus>\n" +
				    "        <ViewID>MCFInfo</ViewID>"+rejectReasonTag+"\n" +
				    "    </NotifyBBGApplicationStatusRequest>\n" +
				    "</EE_EAI_MESSAGE>");
			
			mqInputRequest = getMQInputXML(sessionID, cabinetName,wi_name, ws_name, userName, NotifyInputXML);
			String InputxmlMasked = mqInputRequest;
			InputxmlMasked = maskXmlogBasedOnCallType(InputxmlMasked,"NotifyCall",iformObj);
			DBS.mLogger.debug("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", mqInputRequest for Collect Charge" + InputxmlMasked);
			
		}
		
		try {
			String sMQuery = "SELECT SocketServerIP,SocketServerPort FROM NG_BPM_MQ_TABLE with (nolock) where ProcessName = 'DBS' and CallingSource = 'Form'";
			List<List<String>> outputMQXML = iformObj.getDataFromDB(sMQuery);
			if (!outputMQXML.isEmpty()) {
				socketServerIP = outputMQXML.get(0).get(0);
				socketServerPort = Integer.parseInt(outputMQXML.get(0).get(1));
				if (!("".equalsIgnoreCase(socketServerIP) && socketServerIP == null && socketServerPort==0)) {
					socket = new Socket(socketServerIP, socketServerPort);
					int connection_timeout=60;
					try{
						connection_timeout=70;
					}
					catch(Exception e){
						connection_timeout=60;
					}
					
					socket.setSoTimeout(connection_timeout*1000);
					out = socket.getOutputStream();
					socketInputStream = socket.getInputStream();
					dout = new DataOutputStream(out);
					din = new DataInputStream(socketInputStream);
					DBS.mLogger.debug("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", dout " + dout);
					DBS.mLogger.debug("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", din " + din);
					mqOutputResponse = "";
					
					if (mqInputRequest != null && mqInputRequest.length() > 0) {
						int outPut_len = mqInputRequest.getBytes("UTF-16LE").length;
						DBS.mLogger.debug("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", Final XML output len: "+outPut_len + "");
						mqInputRequest = outPut_len + "##8##;" + mqInputRequest;
						DBS.mLogger.debug("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", MqInputRequest"+"Input Request Bytes : "+ mqInputRequest.getBytes("UTF-16LE"));
						dout.write(mqInputRequest.getBytes("UTF-16LE"));
						dout.flush();
					}
					byte[] readBuffer = new byte[500];
					int num = din.read(readBuffer);
					if (num > 0) {
						
						byte[] arrayBytes = new byte[num];
						System.arraycopy(readBuffer, 0, arrayBytes, 0, num);
						mqOutputResponse = mqOutputResponse+ new String(arrayBytes, "UTF-16LE");		
						/*if(!"".equalsIgnoreCase(mqOutputResponse) && control.equalsIgnoreCase("BAL_FETCH_BTN")) 
						{
							mqOutputResponse = getOutWtthMessageID("ACCOUNT_DETAILS",iformObj,mqOutputResponse);
						}*/
						if(!"".equalsIgnoreCase(mqOutputResponse) && control.equalsIgnoreCase("COLLECTCHARGE"))
						{
							mqOutputResponse = getOutWtthMessageID("CHARGE_COLLECTION",iformObj,mqOutputResponse);
						}
						if(!"".equalsIgnoreCase(mqOutputResponse) && control.equalsIgnoreCase("AWB_GENERATION"))
						{
							mqOutputResponse = getOutWtthMessageID("AWB_GENERATION",iformObj,mqOutputResponse);
						}
						if(!"".equalsIgnoreCase(mqOutputResponse) && control.equalsIgnoreCase("NotifyCall"))
						{
							mqOutputResponse = getOutWtthMessageID("NOTIFY_BBG_APPLICATION",iformObj,mqOutputResponse);
						}
							
							
						if(mqOutputResponse.contains("&lt;")){
							mqOutputResponse=mqOutputResponse.replaceAll("&lt;", "<");
							mqOutputResponse=mqOutputResponse.replaceAll("&gt;", ">");
						}
					}
					socket.close();
				
					return mqOutputResponse;
					
				} else {
					DBS.mLogger.debug("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", SocketServerIp and SocketServerPort is not maintained "+"");
					DBS.mLogger.debug("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", SocketServerIp is not maintained "+	socketServerIP);
					DBS.mLogger.debug("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", SocketServerPort is not maintained "+	socketServerPort);
					return "MQ details not maintained";
				}
			}
			else {
				DBS.mLogger.debug("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", SOcket details are not maintained in NG_BPM_MQ_TABLE table"+"");
				return "MQ details not maintained";
			}
			
			} catch (Exception e) {
				DBS.mLogger.debug("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", Exception Occured Mq_connection_CC"+e.getStackTrace());
			return "";
			}
			finally{
				try{
					if(out != null){					
						out.close();
						out=null;
					}
					if(socketInputStream != null){
						
						socketInputStream.close();
						socketInputStream=null;
					}
					if(dout != null){
						
						dout.close();
						dout=null;
					}
					if(din != null){
						
						din.close();
						din=null;
					}
					if(socket != null){
						if(!socket.isClosed()){
							socket.close();
						}
						socket=null;
					}
				} 
				catch(Exception e)
				{
					DBS.mLogger.debug("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", Final Exception Occured Mq_connection_CC"+e.getStackTrace());
				}
			}
	}

}
