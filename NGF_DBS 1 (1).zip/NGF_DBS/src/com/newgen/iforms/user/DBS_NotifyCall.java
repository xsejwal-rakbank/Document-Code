
package com.newgen.iforms.user;

import java.io.IOException;


import com.newgen.iforms.custom.IFormReference;
import com.newgen.omni.jts.cmgr.XMLParser;

public class DBS_NotifyCall extends DBSCommon {
	
	public String NotifyCall(IFormReference iformObj,String StringData) throws IOException {
		String returnValue = "";
		String MQ_response = "";
		
		
		MQ_response = new DBS_Integration().MQ_connection_response(iformObj,"NotifyCall",StringData);
	
		
		if (MQ_response.indexOf("<StatusDescription>") != -1)
			returnValue = MQ_response.substring(MQ_response.indexOf("<StatusDescription>") + "</StatusDescription>".length() - 1,MQ_response.indexOf("</StatusDescription>"));

		if (MQ_response.contains("INVALID SESSION"))
			returnValue = "INVALID SESSION";

		if ("Success".equalsIgnoreCase(returnValue))
			 returnValue = MQ_response;
			returnValue = "NOTIFY CALL SUCCESS";
		
		XMLParser xmlParserSocketDetails = new XMLParser(MQ_response);
		DBS.mLogger.debug(" xmlParserSocketDetails : " + xmlParserSocketDetails);
		
		String returnCode = xmlParserSocketDetails.getValueOf("ReturnCode");
		try{
		if("0000".equalsIgnoreCase(returnCode) && "NOTIFY CALL SUCCESS".equalsIgnoreCase(returnValue)){
			
			DBS.mLogger.debug(" NOTIFY CALL Status :  NOTIFY CALL SUCCESS");
			// update table after notifying DEH
			return "NOTIFY CALL SUCCESS";
		
		}else{
			DBS.mLogger.debug("NOTIFY CALL Status : Some Error Occured at Server End");
			return "Some Error Occured at Server End";
		}
		}catch(Exception e){
			DBS.mLogger.info("Exception :::::  "  + e.getMessage());
			return "Some Error Occured at Server End";
		}

	}
}
