package com.newgen.iforms.user;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.myfaces.dateformat.SimpleDateFormatter;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.newgen.iforms.custom.IFormReference;
import com.newgen.iforms.xmlapi.IFormXmlResponse;
import com.newgen.json.JSONArray;
import com.newgen.json.JSONObject;
import com.newgen.omni.wf.util.app.NGEjbClient;
import com.newgen.omni.wf.util.excp.NGException;

import ISPack.CPISDocumentTxn;
import ISPack.ISUtil.JPDBRecoverDocData;
import ISPack.ISUtil.JPISException;
import ISPack.ISUtil.JPISIsIndex;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;


@SuppressWarnings("unchecked")
public class DBSCommon extends DBS {
	public static HashMap<String,String>serviceReqMap = new HashMap<>();
	public String serviceReqCode="";
private static NGEjbClient ngEjbClientDBSStatus;
	
	static
	{
	  try
      {
		  ngEjbClientDBSStatus = NGEjbClient.getSharedInstance();
      }
    catch (NGException e)
      {
        // TODO Auto-generated catch block
        e.printStackTrace();
      }
	}

    String sLocaleForMessage = java.util.Locale.getDefault().toString();

    public List < List < String >> getDataFromDB(String query,IFormReference iformObj) {
        DBS.mLogger.debug("WINAME : " + getWorkitemName(iformObj) + ", WSNAME: " + getActivityName(iformObj) + ", Inside Done()--->query is: " + query);
        try {
            List < List < String >> result = (iformObj).getDataFromDB(query);
            DBS.mLogger.debug("WINAME : " + getWorkitemName(iformObj) + ", WSNAME: " + getActivityName(iformObj) + ", Inside Done()---result:" + result);
            if (!result.isEmpty() && result.get(0) != null) {
                return result;
            }
        } catch (Exception e) {
            DBS.printException(e);
        }
        return null;
    }

    public String saveDataInDB(String query,IFormReference iformObj) {
        DBS.mLogger.debug("WINAME : " + getWorkitemName(iformObj) + ", WSNAME: " + getActivityName(iformObj) + ", Inside Done()---Exception_Mail_ID->query is: " + query);
        try {
            int mainCode = iformObj.saveDataInDB(query);
            DBS.mLogger.debug("WINAME : " + getWorkitemName(iformObj) + ", WSNAME: " + getActivityName(iformObj) + ", Inside Done()---result:" + mainCode);
            return mainCode + "";
        } catch (Exception e) {
            DBS.printException(e);
        }
        return null;
    }
    
    public String getUserGroup(String query,IFormReference iformObj) {
        DBS.mLogger.debug("WINAME : " + getWorkitemName(iformObj) + ", WSNAME: " + getActivityName(iformObj) + ", To get User Group Name ->query is: " + query);
        try {
        	  String groupName = "";
 			 // to get user group to insert in decision history start
 			try {
 				DBS.mLogger.info("To insert user group in decision history  ...");
 				DBS.mLogger.info("Query--" + query);
 				List<List<String>> lstDecisions = iformObj.getDataFromDB(query);
 				DBS.mLogger.info("Result  ..." + lstDecisions);
 				List<String> arr1 =  lstDecisions.get(0);
 				groupName = arr1.get(0);
 				DBS.mLogger.debug("value of groupName " + groupName);
 			} catch (Exception e) {
 				DBS.mLogger.debug("WINAME: " + getWorkitemName(iformObj) + ", WSNAME: " + getActivityName(iformObj)
 						+ ", Exception in getting user group for decision history: " + e.getMessage());
 			}
 			
 		    // to insert user group in decision history end
            return groupName;
        } catch (Exception e) {
            DBS.printException(e);
        }
        return null;
    }
    
    
    
    
    //**********************************************************************************//
    //Description            	:Method to Trim Strings
    //**********************************************************************************//
    public String Trim(String str) {
        if (str == null) return str;
        int i = 0, j = 0;
        for (i = 0; i < str.length(); i++) {
            if (str.charAt(i) != ' ')
                break;
        }
        for (j = str.length() - 1; j >= 0; j--) {
            if (str.charAt(j) != ' ')
                break;
        }
        if (j < i) j = i - 1;
        str = str.substring(i, j + 1);
        return str;
    }
    
    public String uniqueIDGeneration(String prefix){
    	
    	String timeStamp = "";
		Date date = new Date();
		
		String year = date.getYear() +1900 +"";
		String month = date.getMonth() +1 +"";
		month = Integer.parseInt(month) <= 9 ? "0" + month : month;
		String curDate = date.getDate() +"";
		curDate = Integer.parseInt(curDate) <= 9 ? "0" + curDate : curDate;
		
		String hours = date.getHours() +"";
		String minutes = date.getMinutes() +"";
		String seconds = date.getSeconds() +"";
		timeStamp = prefix + year + month + curDate + hours + minutes + seconds; 
		
		return timeStamp;
    }

    public void enableControl(String strFields,IFormReference iformObj) {
        String arrFields[] = strFields.split(",");
        for (int idx = 0; idx < arrFields.length; idx++) {
            try {
            	iformObj.setStyle(arrFields[idx], "disable", "false");
            } catch (Exception ex) {
                DBS.printException(ex);
            }
        }
    }
    public void disableControl(String strFields,IFormReference iformObj) {
        String arrFields[] = strFields.split(",");
        for (int idx = 0; idx < arrFields.length; idx++) {
            try {
            	iformObj.setStyle(arrFields[idx], "disable", "true");
            } catch (Exception ex) {
                DBS.printException(ex);
            }
        }
    }
    public void hideControl(String strFields,IFormReference iformObj) {
        String arrFields[] = strFields.split(",");
        for (int idx = 0; idx < arrFields.length; idx++) {
            try {
                iformObj.setStyle(arrFields[idx], "visible", "false");
            } catch (Exception ex) {
                DBS.printException(ex);
            }
        }
    }
    public void showControl(String strFields,IFormReference iformObj) {
        String arrFields[] = strFields.split(",");
        for (int idx = 0; idx < arrFields.length; idx++) {
            try {
                iformObj.setStyle(arrFields[idx], "visible", "true");
            } catch (Exception ex) {
                DBS.printException(ex);
            }
        }
    }
    public void mandatoryControl(String strFields,IFormReference iformObj) {
        String arrFields[] = strFields.split(",");
        for (int idx = 0; idx < arrFields.length; idx++) {
            try {
                iformObj.setStyle(arrFields[idx], "mandatory", "true");
            } catch (Exception ex) {
                DBS.printException(ex);
            }
        }
    }
    public void nonmandatoryControl(String strFields,IFormReference iformObj) {
        String arrFields[] = strFields.split(",");
        for (int idx = 0; idx < arrFields.length; idx++) {
            try {
                iformObj.setStyle(arrFields[idx], "mandatory", "false");
            } catch (Exception ex) {
                DBS.printException(ex);
            }
        }
    }

    

    public void lockControl(String strFields,IFormReference iformObj) {
        String arrFields[] = strFields.split(",");
        for (int idx = 0; idx < arrFields.length; idx++) {
            try {
                iformObj.getIFormControl(arrFields[idx]).getM_objControlStyle().setM_strReadOnly("true");
            } catch (Exception ex) {
                DBS.printException(ex);
            }
        }
    }

    public void unlockControl(String strFields,IFormReference iformObj) {
        String arrFields[] = strFields.split(",");
        for (int idx = 0; idx < arrFields.length; idx++) {
            try {
                iformObj.getIFormControl(arrFields[idx]).getM_objControlStyle().setM_strReadOnly("false");
            } catch (Exception ex) {
                DBS.printException(ex);
            }
        }
    }

    public void clearCombos(String controlName,IFormReference iformObj) {
        String arrFields[] = controlName.split(",");
        for (int i = 0; i < arrFields.length; i++)
            try {
                iformObj.clearCombo(controlName);
            } catch (Exception e) {
                DBS.printException(e);
            }
    }
    public void clearCombo(String controlName,IFormReference iformObj) {
        try {
            iformObj.clearCombo(controlName);
        } catch (Exception e) {
            DBS.printException(e);
        }
    }

    public void addItemInCombo(String arg0, String arg1, String arg2,IFormReference iformObj) {
        try {
            iformObj.addItemInCombo(arg0, arg1, arg2);
        } catch (Exception e) {
            DBS.printException(e);
        }
    }

    public String getSessionId(IFormReference iformObj) {
        return ((iformObj).getObjGeneralData()).getM_strDMSSessionId();
    }

    public String getItemIndex(IFormReference iformObj) {
        return ((iformObj).getObjGeneralData()).getM_strFolderId();
    }

    public String getWorkitemName(IFormReference iformObj) {
        return ((iformObj).getObjGeneralData()).getM_strProcessInstanceId();
    }

    public void setControlValue(String controlName, String controlValue,IFormReference iformObj) {
        iformObj.setValue(controlName, controlValue);
    }

    public String getCabinetName(IFormReference iformObj) {
        return (String) iformObj.getCabinetName();
    }

    public String getUserName(IFormReference iformObj) {
        return (String) iformObj.getUserName();
    }

    public String getActivityName(IFormReference iformObj) {
        return (String) iformObj.getActivityName();
    }

    

    public String getControlValue(String controlName,IFormReference iformObj) {
        return (String) iformObj.getValue(controlName);
    }

    public boolean isControValueEmpty(String controlName,IFormReference iformObj) {
        String controlValue = getControlValue(controlName,iformObj);

        if (controlValue == null || controlValue.equals(""))
            return true;
        else
            return false;
    }
	 @SuppressWarnings("unchecked")
	 public void AddDataToChecKlistGrid(String query, String gridId,IFormReference iformObj)
	    {
	 	  try {
	 		  DBS.mLogger.debug("Inside AddDataToChecKlistGrid.." + gridId);
	 			 List < List < String >> result =getDataFromDB(query,iformObj);
	 			 DBS.mLogger.debug(" getDataFromDB---result:" + result);
	 	         JSONArray jsonArray=new JSONArray();
	 	         if (!result.isEmpty() && result.get(0) != null) {
	 	        	 int i=0;
	 	        	 List < String > options = new ArrayList<String>();
	 	        	 for (List < String > row :result)
	 				{
	 	        		 JSONObject obj=new JSONObject();
	 	        		 String description=row.get(0);
	 	        		
	 	        		 options.add(row.get(1));
	 	        	
	 	        		 obj.put("Description",description);
	 	     
	 	        		 jsonArray.add(obj);
	 	        	
	 	        		 i++;
	               }
	 	        	 DBS.mLogger.info("Inside ChecklistValidations..Final Json Array - "+jsonArray);
	 	        	//iformObj.addDataToGrid(gridId, jsonArray);
	 	        	 DBS.mLogger.info("Inside ChecklistValidations..Add Options--"+options);
	 	        	// addOptionToGrid(options,i,gridId,iformObj);
	          	}
	      } catch (Exception e) {
	          DBS.printException(e);
	          DBS.mLogger.debug("Some Error occured in AddDataToChecKlistGrid .." + e.toString());
	      }
	    }


    public String convertDateFormat(String idate, String ipDateFormat, String opDateFormat, IFormReference iformObj,Locale...opLocale) {
        Locale defaultLocale = Locale.getDefault();

        DBS.mLogger.debug("WINAME : " + getWorkitemName(iformObj) + ", WSNAME: " + getActivityName(iformObj) + ", defaultLocale : " + defaultLocale);

        assert opLocale.length <= 1;
        Locale opDateFmtLocale = opLocale.length > 0 ? opLocale[0] : defaultLocale;

        DBS.mLogger.debug("WINAME : " + getWorkitemName(iformObj) + ", WSNAME: " + getActivityName(iformObj) + ", Loacle for output Date : " + opDateFmtLocale);
        try {
            if (idate == null) {
                return "";
            }
            if (idate.equalsIgnoreCase("")) {
                return "";
            }
            DBS.mLogger.debug("WINAME : " + getWorkitemName(iformObj) + ", WSNAME: " + getActivityName(iformObj) + ", idate :" + idate);
            String odate = "";
            DateFormat dfinput = new SimpleDateFormat(ipDateFormat);
            DateFormat dfoutput = new SimpleDateFormat(opDateFormat, opDateFmtLocale);

            Date dt = dfinput.parse(idate);
            DBS.mLogger.debug("WINAME : " + getWorkitemName(iformObj) + ", WSNAME: " + getActivityName(iformObj) + ", Indate " + dt);
            odate = dfoutput.format(dt);
            DBS.mLogger.debug("WINAME : " + getWorkitemName(iformObj) + ", WSNAME: " + getActivityName(iformObj) + ", Outdate " + odate);
            return odate;
        } catch (Exception e) {
            return "";
        }
    }

    public static String getCurrentDate(String outputFormat) {
        String current_date = "";
        try {
            Date date=new Date();
            SimpleDateFormat formatter=new SimpleDateFormat(outputFormat);
            current_date=formatter.format(date);
        } catch (Exception e) {
            System.out.println("Exception in getting Current date :" + e);
        }
        return current_date;
    }
    
   /* public void printException(Exception e) {
        DBS.printException(e);
    }*/

  
    public String getCurrentTimeStamp() {
        try {
            return new Timestamp(System.currentTimeMillis()).toString();
        } catch (Exception e) {
            printException(e);
            return "";
        }
    }
    
    public String readFile(String path) {
        try {
            File xmlFile = new File(path);
            Reader fileReader = new FileReader(xmlFile);
            BufferedReader bufReader = new BufferedReader(fileReader);

            StringBuilder sb = new StringBuilder();
            String line = bufReader.readLine();
            while (line != null) {
                sb.append(line).append("\n");
                line = bufReader.readLine();
            }
            String xml2String = sb.toString();
            System.out.println("XML to String using BufferedReader : ");
            System.out.println(xml2String);

            bufReader.close();
            DBS.mLogger.info("readFile with Values: " + xml2String);
            return xml2String;
        } catch (Exception e) {
            DBS.mLogger.info("Exceptions: " + e);
            return "";
        }

    }
    public void responseInsertinDB(String call_name, String request, String response, String successindicator, String wi_name,IFormReference iformObj) {
        String currDate = new SimpleDateFormat("dd/MM/yyyy HH:mm").format(Calendar.getInstance().getTime()).toString();

        String Query = "insert into NG_DBS_xml_log_table(CALL_NAME,DATETIME_STAMP,REQUEST,RESPONSE,successIndicator,WI_NAME) values('" + call_name + "','" + currDate + "','" + request + "','" + response.replaceAll("'", "\"") + "','" + successindicator + "','" + wi_name + "')";

        saveDataInDB(Query,iformObj);
    }
    
    public static String convertDate(String inputDate) {
        // Define the input and output date formats
        DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        // Parse the input date
        LocalDate date = LocalDate.parse(inputDate, inputFormatter);

        // Format the date to the desired output format
        return date.format(outputFormatter);
    }
    
    
 public static String getASCIIValuesFromArabic(String inputParam) throws ParseException{
	 String retValue="";
 	if(inputParam.isEmpty()) {
 		return retValue;
 	}
 	
 	String[] scanArray = inputParam.split("");
		for(int i=0;i<scanArray.length;i++)
		{ 
			
			String x = scanArray[i];
			//if(x>194)
			//{
			switch(x)
			
			{
				case " ":
				retValue+= "32";
				break;

				case "ا":
				retValue+=   "199";
				break;
				
				case "ب":
				retValue+= "200";
				break;
				
				case "ت":
				retValue+= "202";
				break;
				
				case "ث":
				retValue+= "203";
				break;
				
				case "ج":
				retValue+= "204";
				break;
				
				case  "ح":
				retValue+="205";
				break;
				
				case "خ":
				retValue+= "206";
				break;
				
				case "د":
				retValue+= "207";
				break;
				
				case "ذ":
				retValue+= "208";
				break;
				
				case "ر":
				retValue+= "209";
				
				break;
				
				case "ز":
				retValue+= "210";
				break;
				
				case "س":
				retValue+= "211";
				break;
				
				case "ش":
				retValue+= "212";
				break;
				
				case "ص":
				retValue+= "213";
				break;
				
				case "ض":
				retValue+= "214";
				break;
				
				case "ط":
				retValue+= "216";
				break;
				
				case "ظ":
				retValue+= "217";
				break;
				
				case "ع":
				retValue+= "218";
				break;
				
				case "غ":
				retValue+= "219";
				break;
				
				case "�?":
				retValue+= "221";
				break;
				
				case "ق":
				retValue+= "222";
				break;
				
				case "ك":
				retValue+= "223";
				break;
				
				case "ل":
				retValue+= "225";
				break;
				
				case "م":
				retValue+= "227";
				break;
				
				case "ن":
				retValue+= "228";
				break;
				
				case "ه":
				retValue+= "229";
				break;
				
				case "و":
				retValue+= "230";
				break;
				
				case "ي":
				retValue+= "237";
				break;
				
				case "آ":
				retValue+= "194";
				break;
				
				case "ة":
				retValue+= "201";
				break;
				
				case  "ى":
				retValue+="236";
				break;
			
				case  "ؤ":
				retValue+="196";
				break;
				
				case "ئ":
				retValue+= "198";
				break;
				
				// case 220:
				// break;
				case "أ":
				retValue+= "195";
				break;
				
				case "إ":
				retValue+= "197";
				
				break;			 
				
				default:
					retValue+= "";
				break;
				
			}
				if(i < scanArray.length - 1) {
					retValue+= "-";
				}
			}
		
		return retValue;
		
	
 }
    


 
 public static String GetTagValue(String XML , String Tagname)
 {
	 String starttag = "<"+Tagname+">";
	 String endtag = "</"+Tagname+">";
	 DBS.mLogger.info("GetTagValue " + starttag);
	 if(XML.indexOf(starttag)>=0)
	 {
		 if("MATURITYDATE".equals(Tagname))
		 {
			 String date = XML.substring(XML.indexOf(starttag)+(starttag.length()),XML.indexOf(endtag));
			 return date.substring(6,8)+date.substring(4,6)+date.substring(0,4);
		 }
	 return XML.substring(XML.indexOf(starttag)+(starttag.length()),XML.indexOf(endtag));
	 }
	 else
	 {
		 return "";
	 }
 }
 
 
 public String getdateCurrentDateInSQLFormat()
	{
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return simpleDateFormat.format(new Date());
	}


 
 
 public String setCutOffDate(String str, IFormReference iform) {
	 String rs = null;
	 String date = null;
	 try {
	 String query = "SELECT CONST_FIELD_VALUE FROM USR_0_BPM_CONSTANTS WITH(nolock) WHERE CONST_FIELD_NAME='DBS_Cut_Off_Date'";
		List<List<String>> data = getDataFromDB(query, iform);
		if(!data.isEmpty()) {
			date = data.get(0).get(0);
		}
		//Date dt = addOneMonth(str);
	 	// DBS.mLogger.info("Date" + dt.toString());
		//SimpleDateFormat sdf = new SimpleDateFormat("MM/yyyy HH:mm:ss");
		//  rs = sdf.format(dt);
	 	 DBS.mLogger.info("Date" + rs.toString());
		rs = date+"/"+rs;
	 }catch(Exception e) {
		 
	 }
	 
	 return rs;
 }
 
 
 
 public  boolean insertReqRespINDatabase(IFormReference iform,String department,String monthYear,String tableID)
 {
	 try
	 {
				
				 String params="'"+getWorkitemName(iform)+"'"
				 +",'" +department+"'"
				 +",'" +monthYear+"'"
				 +",'" +tableID+"'";
				 String inputXML = getAPProcedureInputXML(iform.getCabinetName(),getSessionId(iform),"NG_DBS_INSERT_DATA_INTO_CMPTBL",params);
				 //WriteLog("inputXML AP Procedure new params: "+params);
				 DBS.mLogger.info("inputXML AP Procedure XML Entry "+inputXML);
				 String sOutputXML=WFNGExecute(inputXML, iform.getServerIp(), iform.getServerPort());
				 DBS.mLogger.info("outputXML AP Procedure XML Entry "+sOutputXML);
				
				
				
				 if(sOutputXML.indexOf("<MainCode>0</MainCode>")>-1)
				 {
					 DBS.mLogger.info("inputXML AP Procedure Insert Successful");
					 return true;
				 }
				 else
				 {
					 DBS.mLogger.info("inputXML AP Procedure Insert Failed");
					 return false;
				 }
		}
		 catch(Exception e)
		 {
		 e.printStackTrace();
		 }
	 	return false;
 }
 private String getAPProcedureInputXML(String engineName,String sSessionId,String procName,String Params)
 {
	 StringBuffer bfrInputXML = new StringBuffer();
	 bfrInputXML.append("<?xml version=\"1.0\"?>\n");
	 bfrInputXML.append("<APProcedure_WithDBS_Input>\n");
	 bfrInputXML.append("<Option>APProcedure_WithDBS</Option>\n");
	 bfrInputXML.append("<ProcName>");
	 bfrInputXML.append(procName);
	 bfrInputXML.append("</ProcName>");
	 bfrInputXML.append("<Params>");
	 bfrInputXML.append(Params);
	 bfrInputXML.append("</Params>");
	 bfrInputXML.append("<EngineName>");
	 bfrInputXML.append(engineName);
	 bfrInputXML.append("</EngineName>");
	 bfrInputXML.append("<SessionId>");
	 bfrInputXML.append(sSessionId);
	 bfrInputXML.append("</SessionId>");
	 bfrInputXML.append("</APProcedure_WithDBS_Input>");
	 return bfrInputXML.toString();
 }
 
 protected static String WFNGExecute(String ipXML, String jtsServerIP, String serverPort) throws IOException, Exception
	{
		DBS.mLogger.info("In WF NG Execute : " + serverPort);
		try
		{
			/*if (serverPort.startsWith("33"))
				return WFCallBroker.execute(ipXML, jtsServerIP,
						Integer.parseInt(serverPort), 1);
			else*/
				return ngEjbClientDBSStatus.makeCall(jtsServerIP, serverPort,
						"WebSphere", ipXML);
		}
		catch (Exception e)
		{
			DBS.mLogger.info("Exception Occured in WF NG Execute : "
					+ e.getMessage());
			e.printStackTrace();
			return "Error";
		}
	}

 


public  String getWorkItemInput(String sCabinetName, String sessionID, String workItemName, String WorkItemID)
{
	StringBuffer ipXMLBuffer=new StringBuffer();

	ipXMLBuffer.append("<?xml version=\"1.0\"?>\n");
	ipXMLBuffer.append("<WMGetWorkItem_Input>\n");
	ipXMLBuffer.append("<Option>WMGetWorkItem</Option>\n");
	ipXMLBuffer.append("<EngineName>");
	ipXMLBuffer.append(sCabinetName);
	ipXMLBuffer.append("</EngineName>\n");
	ipXMLBuffer.append("<SessionId>");
	ipXMLBuffer.append(sessionID);
	ipXMLBuffer.append("</SessionId>\n");
	ipXMLBuffer.append("<ProcessInstanceId>");
	ipXMLBuffer.append(workItemName);
	ipXMLBuffer.append("</ProcessInstanceId>\n");
	ipXMLBuffer.append("<WorkItemId>");
	ipXMLBuffer.append(WorkItemID);
	ipXMLBuffer.append("</WorkItemId>\n");
	ipXMLBuffer.append("</WMGetWorkItem_Input>");

	return ipXMLBuffer.toString();
}

//below method is used to Mask specific tag value 
public static String maskXmlTags(String InputXML,String Tag,IFormReference iformObj)
{
    Pattern p = Pattern.compile("(?<="+Tag+")([-\\s\\w]*)((?:[a-zA-Z0-9][-_\\s]*){0})");
    Matcher m = p.matcher(InputXML);
    StringBuffer maskedResult = new StringBuffer();
    while (m.find()) 
    {
        String thisMask = m.group(1).replaceAll("[^-_\\s]", "*");
        m.appendReplacement(maskedResult, thisMask + "$2");
    }
    m.appendTail(maskedResult);
    return maskedResult.toString();
}
public String maskXmlogBasedOnCallType(String outputxmlMasked, String callType,IFormReference iformObj)
{
	String Tags = "";
	if (callType.equalsIgnoreCase("ENTITY_DETAILS"))
	{
		outputxmlMasked = outputxmlMasked.replace("("," ").replace(")"," ").replace("@"," ").replace("+"," ").replace("&amp;/"," ").replace("&amp; /"," ").replace("."," ").replace(","," ");
		Tags = "<ACCNumber>~,~<CIFID>~,~<AccountName>~,~<ECRNumber>~,~<DOB>~,~<MothersName>~,~<IBANNumber>~,~<DocId>~,~<DocExpDt>~,~<DocIssDate>~,~<PassportNum>~,~<MotherMaidenName>~,~<LinkedDebitCardNumber>~,~<FirstName>~,~<MiddleName>~,~<LastName>~,~<FullName>~,~<ARMCode>~,~<ARMName>~,~<PhnCountryCode>~,~<PhnLocalCode>~,~<PhoneNo>~,~<EmailID>~,~<CustomerName>~,~<CustomerMobileNumber>~,~<PrimaryEmailId>~,~<Fax>~,~<AddressType>~,~<AddrLine1>~,~<AddrLine2>~,~<AddrLine3>~,~<AddrLine4>~,~<POBox>~,~<City>~,~<Country>~,~<AddressLine1>~,~<AddressLine2>~,~<AddressLine3>~,~<AddressLine4>~,~<CityCode>~,~<State>~,~<CountryCode>~,~<Nationality>~,~<ResidentCountry>~,~<PrimaryContactName>~,~<PrimaryContactNum>~,~<SecondaryContactName>~,~<SecondaryContactNum>";
	}
	else if (callType.equalsIgnoreCase("ACCOUNT_SUMMARY"))
	{
		outputxmlMasked = outputxmlMasked.replace("("," ").replace(")"," ").replace("@"," ").replace("+"," ").replace("&amp;/"," ").replace("&amp; /"," ").replace("."," ").replace(","," ");
		Tags = "<Acid>~,~<CIFID>~,~<Foracid>~,~<NicName>~,~<AccountName>~,~<AcctBal>~,~<LoanAmtAED>~,~<AcctOpnDt>~,~<MaturityAmt>~,~<EffAvailableBal>~,~<EquivalentAmt>~,~<LedgerBalanceinAED>~,~<LedgerBalance>";
	}
	else if (callType.equalsIgnoreCase("SIGNATURE_DETAILS"))
	{
		outputxmlMasked = outputxmlMasked.replace("&amp;/"," ").replace("&amp; /"," ").replace("."," ").replace(","," ");
		Tags = "<CustomerName>";
	}
	else if (callType.equalsIgnoreCase("BLACKLIST_DETAILS"))
    {
          outputxmlMasked = outputxmlMasked.replace("&amp;/"," ").replace("&amp; /"," ").replace("."," ").replace(","," ");
          Tags = "<FirstName>~,~<MiddleName>~,~<LastName>~,~<DateOfBirth>~,~<CorporateName>~,~<CountryOfIncorporation>~,~<CustomerStatus>~,~<CustDormStatus>~,~<DocumentType>~,~<DocumentRefNumber>~,~<PhoneType>~,~<PhoneValue>~,~<StatusType>~,~<StatusFlag>~,~<StatusNotes>~,~<StatusReason>~,~<ProductType>~,~<ReferenceNumber>~,~<Unit>~,~<ReasonNotes>~,~<ReasonCodeDesc>~,~<ReasonCode>";
    }
	else if (callType.equalsIgnoreCase("CUSTOMER_SUMMARY"))
    {
          outputxmlMasked = outputxmlMasked.replace("&amp;/"," ").replace("&amp; /"," ").replace("."," ").replace(","," ");
          Tags = "<FName>~,~<LName>~,~<MobileNo>~,~<EmailId>~,~<DOB>~,~<PassportNo>~,~<SubRelationshipStatus>";
    }
	else if (callType.equalsIgnoreCase("DEDUP_SUMMARY"))
    {
          outputxmlMasked = outputxmlMasked.replace("&amp;/"," ").replace("&amp; /"," ").replace("."," ").replace(","," ");
          Tags = "<FirstName>~,~<MiddleName>~,~<LastName>~,~<ShortName>~,~<FullName>~,~<MaritalStatus>~,~<Nationality>~,~<DateOfBirth>~,~<DocumentType>~,~<DocumentRefNumber>~,~<MailIdType>~,~<MailIdValue>~,~<PhoneType>~,~<PhoneValue>~,~<StatusType>~,~<StatusFlag>~,~<ReasonCode>~,~<ReasonNotes>~,~<ReasonStatus>~,~<CreationDate>~,~<CustStatus>~,~<CustDormancy>";
    }
	else if (callType.equalsIgnoreCase("RISK_SCORE_DETAILS"))
    {
          outputxmlMasked = outputxmlMasked.replace("&amp;/"," ").replace("&amp; /"," ").replace("."," ").replace(","," ");
          Tags = "<DemographicScore>~,~<NationalityScore>~,~<CustomerCategoryScore>~,~<IndustryScore>~,~<ProductScore>~,~<OverallRiskRate>~,~<TotalRiskScore>";
    }
	else if (callType.equalsIgnoreCase("ACCOUNT_DETAILS"))
    {
          outputxmlMasked = outputxmlMasked.replace("&amp;/"," ").replace("&amp; /"," ").replace("."," ").replace(","," ");
          Tags = "<Acid>~,~<AcctCurr>~,~<BalType>~,~<Amount>~,~<CurrencyCode>";
    }
	else if (callType.equalsIgnoreCase("COLLECTCHARGE"))
    {
          outputxmlMasked = outputxmlMasked.replace("&amp;/"," ").replace("&amp; /"," ").replace("."," ").replace(","," ");
          Tags = "<TranId>~,~<DebitAcct>";
    }
	else if (callType.equalsIgnoreCase("AUTHORISEDSIGNATORY"))
    {
          outputxmlMasked = outputxmlMasked.replace("&amp;/"," ").replace("&amp; /"," ").replace("."," ").replace(","," ");
          Tags = "<AcctId>";
    }
	else if (callType.equalsIgnoreCase("AWB_GENERATION"))
    {
          outputxmlMasked = outputxmlMasked.replace("&amp;/"," ").replace("&amp; /"," ").replace("."," ").replace(","," ");
          Tags = "<ToCompany>~,~<ToAddress>~,~<ToLocation>~,~<ToCountry>~,~<ToCperson>~,~ToContactno~,~ToMobileno";   
    }
	if (!Tags.equalsIgnoreCase(""))
	{
    	String Tag[] = Tags.split("~,~");
    	for(int i=0;i<Tag.length;i++)
    	{
    		outputxmlMasked = maskXmlTags(outputxmlMasked,Tag[i],iformObj);
    	}
	}
	return outputxmlMasked;
}

public String AttachDocumentWithWI(IFormReference iformObj,String pid,String dynamicPdfName,String DocumentName)
{
	String docxml="";
	String documentindex="";
	String doctype="";
	DBS.mLogger.debug("inside AttachDocuments");	
	
	try
	{			
		DBS.mLogger.debug("inside ODAddDocument");		
		
		DBS.mLogger.debug("Proess Instance Id: "+pid);
		
		String sCabname=iformObj.getCabinetName();
		DBS.mLogger.debug("sCabname"+sCabname);
		
		String sSessionId = getSessionId(iformObj);
		DBS.mLogger.debug("sSessionId"+sSessionId);
		
		String sJtsIp = iformObj.getServerIp();
		
		int iJtsPort_int =Integer.parseInt(iformObj.getServerPort());
		
		//String volume id="1";
		//String sPath="";
		//String dynamicPdfName="";
		
	/*	Properties properties = new Properties();
		try 
        {
			properties.load(new FileInputStream(System.getProperty("user.dir")+ System.getProperty("file.separator")+"CustomConfig"+System.getProperty("file.separator")+"DBS"+System.getProperty("file.separator")+"DBS.properties"));
        } 
        catch (IOException e) 
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }*/
		
		String tempDir = System.getProperty("user.dir");
		String generatedpdfPath = properties.getProperty("DOCUMENT_PATH");//Get the location of the path where generated template will be saved
        generatedpdfPath += dynamicPdfName;
        generatedpdfPath = tempDir + generatedpdfPath;//Complete path of generated document
        DBS.mLogger.debug("\nTemplate Doc generatedpdfPath :" + generatedpdfPath);
		
		docxml = SearchExistingDoc(iformObj,pid,DocumentName,sCabname,sSessionId,sJtsIp,iJtsPort_int,generatedpdfPath);
		DBS.mLogger.debug("Final Document Output: "+docxml);
		documentindex = getTagValue(docxml,"DocumentIndex");
		if(getTagValue(docxml,"Option").equalsIgnoreCase("NGOChangeDocumentProperty")) 
		{
			doctype="deleteadd";
		} 
		else 
		{
			doctype="new";
		}
		DBS.mLogger.debug(docxml+"~"+documentindex+"~"+doctype+"~"+DocumentName);
		String Output="0000~"+docxml+"~"+documentindex+"~"+doctype+"~"+DocumentName;
		return Output;
	} 
	catch (Exception e) 
	{
		DBS.mLogger.debug("Exception while adding the document: "+e);
		return "Exception while adding the document: "+e;
	}
}

public static String SearchExistingDoc(IFormReference iform, String pid, String FrmType, String sCabname,
		String sSessionId, String sJtsIp, int iJtsPort_int, String sFilepath) {
	try {
		String strFolderIndex = "";
		String strImageIndex = "";

		String strInputQry1 = "SELECT FOLDERINDEX,ImageVolumeIndex FROM PDBFOLDER WITH(NOLOCK) WHERE NAME='" + pid
				+ "'";

		short iJtsPort = (short) iJtsPort_int;

		DBS.mLogger.info("sInputXML: " + strInputQry1);

		@SuppressWarnings("unchecked")
		List<List<String>> dataFromDB = iform.getDataFromDB(strInputQry1);
		for (List<String> tableFrmDB : dataFromDB) 
		{
			strFolderIndex = tableFrmDB.get(0).trim();
			// strImageIndex = tableFrmDB.get(1).trim();
			strImageIndex = Integer.toString(iform.getObjGeneralData().getM_iVolId());
		}
		DBS.mLogger.info("strFolderIndex: " + strFolderIndex);
		DBS.mLogger.info("strImageIndex: " + strImageIndex);

		IFormXmlResponse xmlParserData = new IFormXmlResponse();

		if (!(strFolderIndex.equalsIgnoreCase("") && strImageIndex.equalsIgnoreCase(""))) 
		{

			try {
				DBS.mLogger.info("Inside Adding PN File: ");
				DBS.mLogger.info("sFilepath: " + sFilepath);
				String filepath = sFilepath;

				File newfile = new File(filepath);
				String name = newfile.getName();
				String ext = "";
				String sMappedInputXml = "";
				if (name.contains(".")) 
				{
					ext = name.substring(name.lastIndexOf("."), name.length());
				}
				JPISIsIndex ISINDEX = new JPISIsIndex();
				JPDBRecoverDocData JPISDEC = new JPDBRecoverDocData();
				String strDocumentPath = sFilepath;
				File processFile = null;
				long lLngFileSize = 0L;
				processFile = new File(strDocumentPath);

				lLngFileSize = processFile.length();
				String lstrDocFileSize = "";
				lstrDocFileSize = Long.toString(lLngFileSize);

				String createdbyappname = "";
				createdbyappname = ext.replaceFirst(".", "");
				Short volIdShort = Short.valueOf(strImageIndex);

				DBS.mLogger.info("lLngFileSize: --" + lLngFileSize);
				if (lLngFileSize != 0L) 
				{
					DBS.mLogger.info("sJtsIp --" + sJtsIp + " iJtsPort-- " + iJtsPort + " sCabname--" + sCabname
							+ " volIdShort.shortValue() --" + volIdShort.shortValue() + " strDocumentPath--"
							+ strDocumentPath + " JPISDEC --" + JPISDEC + "  ISINDEX-- " + ISINDEX);
					CPISDocumentTxn.AddDocument_MT(null, sJtsIp, iJtsPort, sCabname, volIdShort.shortValue(),
							strDocumentPath, JPISDEC, "", ISINDEX);

				}

				sMappedInputXml = "<?xml version=\"1.0\"?>" + "<NGOAddDocument_Input>"
						+ "<Option>NGOAddDocument</Option>" + "<CabinetName>" + sCabname + "</CabinetName>"
						+ "<UserDBId>" + sSessionId + "</UserDBId>" + "<GroupIndex>0</GroupIndex>"
						+ "<VersionFlag>Y</VersionFlag>" + "<ParentFolderIndex>" + strFolderIndex
						+ "</ParentFolderIndex>" + "<DocumentName>" + FrmType + "</DocumentName>"
						+ "<CreatedByAppName>" + createdbyappname + "</CreatedByAppName>" + "<Comment>"
						+ FrmType + "</Comment>" + "<VolumeIndex>" + ISINDEX.m_sVolumeId + "</VolumeIndex>"
						+ "<FilePath>" + strDocumentPath + "</FilePath>" + "<ISIndex>" + ISINDEX.m_nDocIndex
						+ "#" + ISINDEX.m_sVolumeId + "</ISIndex>" + "<NoOfPages>1</NoOfPages>"
						+ "<DocumentType>N</DocumentType>" + "<DocumentSize>" + lstrDocFileSize
						+ "</DocumentSize>" + "</NGOAddDocument_Input>";

				DBS.mLogger.info("Document Addition sInputXML: " + sMappedInputXml);

				String sOutputXML = ExecuteQueryOnServer(iform, sMappedInputXml);
				xmlParserData.setXmlString((sOutputXML));
				DBS.mLogger.info("Document Addition sOutputXml: " + sOutputXML);
				String status_D = xmlParserData.getVal("Status");
				if (status_D.equalsIgnoreCase("0"))
				{
					return sOutputXML;
				}
				else
				{
					return "Error in Document Addition";
				}
			} 
			catch (JPISException e) 
			{
				return "Error in Document Addition at Volume";
			} 
			catch (Exception e)
			{
				return "Exception Occurred in Document Addition";
			}

		}
		return "Any Error occurred in Addition of Document";
	} 
	catch (Exception e) 
	{
		return "Exception Occurred in SearchDocument";
	}
}
public static String ExecuteQueryOnServer(IFormReference iformObj,String sInputXML)
{
	try
	{
		DBS.mLogger.info("Server Ip :"+iformObj.getServerIp());
		DBS.mLogger.info("Server Port :"+iformObj.getServerPort());
		DBS.mLogger.info("Input XML :"+sInputXML);

		return NGEjbClient.getSharedInstance().makeCall(iformObj.getServerIp(), iformObj.getServerPort() + "", "WEBSPHERE", sInputXML);
	}
	catch(Exception excp)
	{
		DBS.mLogger.info("Exception occured in executing API on server :\n"+excp);
		DBS.mLogger.info(excp);
		return "Exception occured in executing API on server :\n"+excp;
	}       
}
public static Document getDocument(String xml) throws ParserConfigurationException, SAXException, IOException {
	// Step 1: create a DocumentBuilderFactory
	DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

	// Step 2: create a DocumentBuilder
	DocumentBuilder db = dbf.newDocumentBuilder();

	// Step 3: parse the input file to get a Document object
	Document doc = (Document) db.parse(new InputSource(new StringReader(xml)));
	return doc;
}
public static String getTagValue(String xml, String tag) 
{
	try 
	{
		Document doc = getDocument(xml);
		NodeList nodeList =  doc.getElementsByTagName(tag);

		int length = nodeList.getLength();

		if (length > 0) 
		{
			Node node = nodeList.item(0);
			if (node.getNodeType() == Node.ELEMENT_NODE)
			{
				NodeList childNodes = node.getChildNodes();
				String value = "";
				int count = childNodes.getLength();
				for (int i = 0; i < count; i++) 
				{
					Node item = childNodes.item(i);
					if (item.getNodeType() == Node.TEXT_NODE) 
					{
						value += item.getNodeValue();
					}
				}
				return value;
			} 
			else if (node.getNodeType() == Node.TEXT_NODE) 
			{
				return node.getNodeValue();
			}
		}
	} 
	catch (Exception e) 
	{
		DBS.mLogger.info(e);
	}
	return "";
}
public static String DeleteFile(String srcFolderPath) throws FileNotFoundException
{
	try
	{
		File file = new File(srcFolderPath);
		file.delete();
		return "Success";
	}
	catch(Exception e)
	{
		return e.toString();
	}
}
public void getServiceReq(IFormReference iformObj)
{
	DBS.mLogger.info("Inside the getService Method");
	try{
		List serviceReqLists = iformObj.getDataFromDB("select SERVICE_REQ_TYPE,SERVICE_REQ_CODE from USR_0_DBS_SERVICE_REQ_MASTER with(nolock) where ISACTIVE='Y'");
		DBS.mLogger.info("Inside the getService Method"+serviceReqLists);
		for(int i=0;i<serviceReqLists.size();i++)
		{
			List<String> arr1=(List)serviceReqLists.get(i);
			DBS.mLogger.info("Inside the getService Method"+arr1);
			serviceReqMap.put(arr1.get(0), arr1.get(1));
			DBS.mLogger.info("Inside the getService Method"+serviceReqMap);
			
		}	
	}
	catch(Exception e)
	{
		DBS.mLogger.info("Inside catch"+e.getStackTrace());
	}
	//rubi
	//return serviceReqMap;
}


}
