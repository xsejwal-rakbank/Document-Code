package com.newgen.iforms.user;


import java.util.List;
import com.newgen.iforms.custom.IFormReference;


public class DBS_FormLoad extends DBSCommon {

	private String WI_Name = null;
	private String userName = null;
	private String activityName = null;
	//private IFormReference giformObj = null;
	

	public String formLoad(IFormReference iformObj, String control, String stringdata) {
		DBS.mLogger.debug("Inside FormLoad...");
		WI_Name = getWorkitemName(iformObj);
		userName = iformObj.getUserName();
		activityName = iformObj.getActivityName();
		serviceReqCode=(String)iformObj.getValue("SERVICE_REQ_CODE");
		DBS.mLogger.info("Inside the AWB validation Method "+serviceReqCode+" "+serviceReqMap.size());
		//giformObj = iformObj;
		try{
			/***************************************HEADER SECTION LOADING***********************************************/
			
			iformObj.setValue("label_Loggedin", "LoggedIn As: <br><font color =\"black\">" + userName + "</font>");
			iformObj.setValue("label_Workstep", "Workstep: <br><font color =\"black\">" + activityName + "</font>");
			iformObj.setValue("label_WINumber", "Workitem No: <br><font color =\"black\">" + WI_Name + "</font>");
			
			/**************************************************************************************/
			
			/***************************************SECTION VISIBLE ***********************************************/
			String sectionIDs=DBS.properties.getProperty(serviceReqCode);
			hideControl(sectionIDs,iformObj);
			hideControl("COURIER_SECTION",iformObj);
			iformObj.setStyle("BRANCH", "visible", "false");
			if("DBS003".equalsIgnoreCase((String)iformObj.getValue("service_req_code"))){
				iformObj.setValue("DBS003_CC_ACCOUNTNO",(String) iformObj.getValue("CC_ACCOUNTNO"));
				iformObj.setValue("DBS003_CC_ACCTTYPE",(String) iformObj.getValue("CC_ACCTTYPE"));
				iformObj.setValue("DBS003_CC_CURRENCY",(String) iformObj.getValue("CC_CURRENCY"));
				iformObj.setStyle("DELIVERYTYPE", "visible", "true");
				if("Courier".equalsIgnoreCase((String)iformObj.getValue("DELIVERYTYPE"))){
					iformObj.setStyle("COURIER_SECTION", "visible", "true");
					iformObj.setStyle("BRANCH", "visible", "false");
				}
				else
				{
					iformObj.setStyle("COURIER_SECTION", "visible", "false");
					iformObj.setStyle("BRANCH", "visible", "true");
				}
				if("Dispatch".equalsIgnoreCase(activityName)){
					iformObj.setStyle("TEAMEX_LINK","visible","true");
				}
			}
			if("DBS004".equalsIgnoreCase((String)iformObj.getValue("service_req_code"))){
				iformObj.setStyle("RCIF", "visible", "true");
				iformObj.setStyle("NATIONALITY", "visible", "true");
				iformObj.setStyle("RESIDENT_COUNTRY", "visible", "true");
				iformObj.setStyle("DATE_OF_BIRTH", "visible", "true");
				if("OPS_Review".equalsIgnoreCase(activityName)){
	                iformObj.setStyle("NEW_DOC_ID","disable","false");
	                iformObj.setStyle("NEW_DOC_ISSUE_DATE","disable","false");
	                iformObj.setStyle("NEW_DOC_EXP_DATE","disable","false");   
				}
			}
			
		/*	if("DBS005".equalsIgnoreCase((String)iformObj.getValue("service_req_code"))){
				iformObj.setValue("DBS005_CC_ACCOUNTNO",(String) iformObj.getValue("CC_ACCOUNTNO"));
				iformObj.setValue("DBS005_CC_ACCTTYPE",(String) iformObj.getValue("CC_ACCTTYPE"));
				iformObj.setValue("DBS005_CC_CURRENCY",(String) iformObj.getValue("CC_CURRENCY"));
				iformObj.setStyle("RM_EMAILID", "visible", "true");
				iformObj.setStyle("RCIF", "visible", "true");
				if("OPS_Review".equalsIgnoreCase(activityName)){
	                iformObj.setStyle("TRANSFER_CHANNEL","disable","false"); 
				}
				if("OPS_Review_Checker".equalsIgnoreCase(activityName) && "Swift".equalsIgnoreCase((String)iformObj.getValue("TRANSFER_CHANNEL"))){
	                iformObj.setStyle("DBS005_COLLECTCHARGE","visible","true");  
	                iformObj.setStyle("SWIFT_COPY","visible","true");
				}
				else if("OPS_Review_Checker".equalsIgnoreCase(activityName) && "FTS".equalsIgnoreCase((String)iformObj.getValue("TRANSFER_CHANNEL"))){
	                iformObj.setStyle("DBS005_COLLECTCHARGE","visible","true");  
	                iformObj.setStyle("FTS_REF_NO","visible","true");
				}
				if("OPS_Review".equalsIgnoreCase(activityName) && "FTS".equalsIgnoreCase((String)iformObj.getValue("TRANSFER_CHANNEL"))){
					  iformObj.setStyle("FTS_REF_NO","visible","true");
					  iformObj.setStyle("FTS_REF_NO","disable","false");
				}
				else if("OPS_Review".equalsIgnoreCase(activityName) && "Swift".equalsIgnoreCase((String)iformObj.getValue("TRANSFER_CHANNEL"))){
					 iformObj.setStyle("SWIFT_COPY","visible","true");
					 iformObj.setStyle("SWIFT_COPY","disable","false");
				}
			}
			*/
			
			
			if("DBS005".equalsIgnoreCase((String)iformObj.getValue("service_req_code"))){
				
			    iformObj.setStyle("RM_EMAILID", "visible", "true");
			    iformObj.setStyle("RCIF", "visible", "true");
			    
			    String transferChannel = (String) iformObj.getValue("TRANSFER_CHANNEL");
			    String paymentType = (String) iformObj.getValue("PAYMENT_TYPE");
			    boolean isSwift = "Swift".equalsIgnoreCase(transferChannel);
			    boolean isFTS = "FTS".equalsIgnoreCase(transferChannel);
			    boolean isOpsReview = "OPS_Review".equalsIgnoreCase(activityName);
			    boolean isOpsReviewChecker = "OPS_Review_Checker".equalsIgnoreCase(activityName);
			    boolean isAmendment = "Amendment".equalsIgnoreCase((String) iformObj.getValue("REQ_TYPE"));
			    
			    if(isAmendment){
			    	  iformObj.setStyle("AMD_BEN_NAME", "visible", "true");
				       iformObj.setStyle("AMD_PUR_OF_PAYMENT", "visible", "true");
			    }
			    if(isSwift){
		            iformObj.setStyle("SWIFT_COPY", "visible", "true");
		        } else if(isFTS){
		            iformObj.setStyle("FTS_REF_NO", "visible", "true");
		        }
			    
			    // Handle OPS_Review activity
			    if(isOpsReview){
			        iformObj.setStyle("TRANSFER_CHANNEL", "disable", "false");
			        iformObj.setStyle("TRANSFER_CHANNEL", "mandatory", "true");
			        if(isFTS){
			            iformObj.setStyle("FTS_REF_NO", "visible", "true");
			            iformObj.setStyle("FTS_REF_NO", "disable", "false");
			            iformObj.setStyle("FTS_REF_NO", "mandatory", "true");
			        } else if(isSwift){
			            iformObj.setStyle("SWIFT_COPY", "visible", "true");
			            iformObj.setStyle("SWIFT_COPY", "disable", "false");
			            iformObj.setStyle("SWIFT_COPY", "mandatory", "true");
			        }
			    }
			    // Handle OPS_Review_Checker activity
			    else if(isOpsReviewChecker){
			    	if(!("Inward".equalsIgnoreCase(paymentType))){
			    		iformObj.setStyle("DBS005_COLLECTCHARGE", "visible", "true");
			    		if("Y".equalsIgnoreCase((String)iformObj.getValue("IS_CHARGE_COLLECTED")) && isFTS){
							if(!("AED".equalsIgnoreCase((String)iformObj.getValue("CC_CURRENCY"))) &&"Y".equalsIgnoreCase((String)iformObj.getValue("IS_COURIER_CHARGED"))){
								iformObj.setStyle("DBS005_COLLECTCHARGE","disable","true");
							}
							else if("AED".equalsIgnoreCase((String)iformObj.getValue("CC_CURRENCY"))){
								iformObj.setStyle("DBS005_COLLECTCHARGE","disable","true");
							}
						}
			    		else{
			    			 iformObj.setStyle("DBS005_COLLECTCHARGE", "disable", "false");
			    		}
			    	}
			    	else if("Inward".equalsIgnoreCase(paymentType) && isSwift){
			    		iformObj.setStyle("DBS005_COLLECTCHARGE", "visible", "true");
			    		iformObj.setStyle("DBS005_COLLECTCHARGE", "disable", "false");
			    	}
			    }
			}
			
			/**************************************************************************************/

		} catch (Exception exc) {
			DBS.printException(exc);
			DBS.mLogger.info("Error in form load - " + exc);
		}
		
		/*********************Loading Decision**************************/
		try
		{
			if("Initiation".equalsIgnoreCase(activityName))
			{
				serviceReqCode="Initiation";		
			}
			else
			{
				List lstDecisions = iformObj.getDataFromDB("SELECT distinct (DECISION) FROM USR_0_DBS_DECISION_MASTER WITH(NOLOCK) WHERE WORKSTEP_NAME='"+activityName+"' and SERVICE_REQ_CODE='"+serviceReqCode+"' and ISACTIVE='Y' ORDER BY DECISION ASC");
				String value="";
				iformObj.clearCombo("ID_DECISION");
				for(int j=0;j<lstDecisions.size();j++)
				{
					List<String> arr1=(List)lstDecisions.get(j);
					value=arr1.get(0);
					iformObj.addItemInCombo("ID_DECISION",value,value);
				}	
			}
			return "Decision dropdown loaded";
		} 
		catch (Exception e) 
		{
			DBS.mLogger.debug("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+activityName+", Exception in Decision drop down load " + e.getMessage());
		}
		/********************************************************************/
		
		/*********************Loading Reject Reason**************************/
		try
		{
			List lstDecisions = iformObj.getDataFromDB("select REJECT_REASON from USR_0_DBS_REJECT_REASON_MASTER with(nolock) where SERVICE_REQ_CODE='"+serviceReqCode+"' and WORKSTEP_NAME='"+activityName+"' and ISACTIVE='Y'");
			String Rejvalue="";
			iformObj.clearCombo("REJECT_REASON");
			for(int i=0;i<lstDecisions.size();i++)
			{
				List<String> arr1=(List)lstDecisions.get(i);
				Rejvalue=arr1.get(0);
				iformObj.addItemInCombo("REJECT_REASON",Rejvalue,Rejvalue);
			}	
			
		} 
		catch (Exception e) 
		{
			DBS.mLogger.debug("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+activityName+", Exception in REJECT_REASON drop down load " + e.getMessage());
		}
		
		/*****************************************************************/

	     return "";
	}

}
