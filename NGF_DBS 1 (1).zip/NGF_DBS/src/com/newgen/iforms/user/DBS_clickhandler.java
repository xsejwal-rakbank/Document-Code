package com.newgen.iforms.user;

import com.newgen.iforms.custom.IFormReference;


public class DBS_clickhandler extends DBSCommon {

    private static final String EXCEPTION_OCCURED = null;
    private static final String UNHANDLED = null;
    private static final String SUCCESS = null;
    private static final String FAIL = null;
    private String WI_Name = null;
	private String activityName = null;
	private String userName = null;
	private String DECISION = null;
	private String returnMsg="";
	//private IFormReference giformObj = null;
    
    public String onClick(IFormReference iformObj, String control, String stringdata) {
    	DBS.mLogger.info("onClick:::::::::::::::::::::::::::::");
    	activityName=iformObj.getActivityName();
    	WI_Name=getWorkitemName(iformObj);
    	
		//giformObj=iformObj;
		try
		{  
			if("COLLECTCHARGE".equalsIgnoreCase(control)){
				if(!"Y".equalsIgnoreCase((String)iformObj.getValue("IS_CHARGE_COLLECTED")) && !"NA".equalsIgnoreCase((String)iformObj.getValue("IS_CHARGE_COLLECTED")))
				{
					returnMsg=new DBS_Integration().collectCharge(iformObj,"SERVICE_CHARGE");
					DBS.mLogger.debug("IS courier charged after"+iformObj.getValue("IS_COURIER_CHARGED"));
					if("Success".equalsIgnoreCase(returnMsg))
					{
						if("Courier".equalsIgnoreCase((String)iformObj.getValue("DELIVERYTYPE")))
						{
							if(!"Y".equalsIgnoreCase((String)iformObj.getValue("IS_COURIER_CHARGED")) && !"NA".equalsIgnoreCase((String)iformObj.getValue("IS_COURIER_CHARGED")))
							{
								returnMsg=new DBS_Integration().collectCharge(iformObj,"COURIER_CHARGE");
							}
						}
						else if("DBS005".equalsIgnoreCase((String)iformObj.getValue("SERVICE_REQ_CODE")) && ("USD".equalsIgnoreCase((String)iformObj.getValue("CC_CURRENCY")) || "GBP".equalsIgnoreCase((String)iformObj.getValue("CC_CURRENCY")) || "EUR".equalsIgnoreCase((String)iformObj.getValue("CC_CURRENCY"))))
						{
							if(!"Y".equalsIgnoreCase((String)iformObj.getValue("IS_COURIER_CHARGED")) && !"NA".equalsIgnoreCase((String)iformObj.getValue("IS_COURIER_CHARGED")))
							{
								returnMsg=new DBS_Integration().collectCharge(iformObj,"CORRESPONDED_CHARGE");
							}
						}
					}
					else if("Success".equalsIgnoreCase(returnMsg)){
						returnMsg="Success";
					}
					else if("".equalsIgnoreCase(returnMsg)){
						returnMsg="NA";
					}
					/*else{
						returnMsg="Error in collecting the charge";
					}*/
				}
				else
				{
					if("Y".equalsIgnoreCase("IS_CHARGE_COLLECTED"))
					{
						if("Courier".equalsIgnoreCase((String)iformObj.getValue("DELIVERYTYPE")))
						{
							if(!"Y".equalsIgnoreCase((String)iformObj.getValue("IS_COURIER_CHARGED")) && !"NA".equalsIgnoreCase((String)iformObj.getValue("IS_COURIER_CHARGED")))
							{
								returnMsg=new DBS_Integration().collectCharge(iformObj,"COURIER_CHARGE");
							}
						}
						else if("DBS005".equalsIgnoreCase((String)iformObj.getValue("SERVICE_REQ_CODE")) && ("USD".equalsIgnoreCase((String)iformObj.getValue("CC_CURRENCY")) || "GBP".equalsIgnoreCase((String)iformObj.getValue("CC_CURRENCY")) || "EUR".equalsIgnoreCase((String)iformObj.getValue("CC_CURRENCY"))))
						{
							if(!"Y".equalsIgnoreCase((String)iformObj.getValue("IS_COURIER_CHARGED")) && !"NA".equalsIgnoreCase((String)iformObj.getValue("IS_COURIER_CHARGED")))
							{
								returnMsg=new DBS_Integration().collectCharge(iformObj,"CORRESPONDED_CHARGE");
							}
						}
					}
					else if("".equalsIgnoreCase(returnMsg)){
						returnMsg="NA";
					}
					/*else{
						returnMsg="Error in collecting the charge";
					}*/
				}
				DBS.mLogger.debug( "CollectCharge - " +returnMsg);
				if(("Success".equalsIgnoreCase(returnMsg)|| "NA".equalsIgnoreCase(returnMsg)) && !"FTS".equalsIgnoreCase((String)iformObj.getValue("TRANSFER_CHANNEL"))){
					returnMsg=new DBS_CCM_Integration().requestResponseCCMJSON(iformObj);
					DBS.mLogger.debug( "Post DBS_CCM_Integration - "+returnMsg);
				}
			}
			if("AWB_GENERATION".equalsIgnoreCase(control)){
				if(!"Y".equalsIgnoreCase((String)iformObj.getValue("IS_AWB_GENERATED")))
				{
					returnMsg=new DBS_AWB_GENERATION().generateAWB(iformObj,stringdata);
				}
				else if("Y".equalsIgnoreCase((String)iformObj.getValue("IS_AWB_GENERATED")))
				{
					returnMsg="AWB No already generated ";
				}
			}
			
		}
		catch(Exception exc)
		{
    		DBS.printException(exc);
			DBS.mLogger.debug( "Exception 2 - " +exc);
			return EXCEPTION_OCCURED;
		}
		return returnMsg;
    }


}