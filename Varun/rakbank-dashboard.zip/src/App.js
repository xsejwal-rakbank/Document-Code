import { Activity, ArrowDown, ArrowUp, DollarSign, TrendingUp, Users } from 'lucide-react';
import { createContext, useContext, useEffect, useState } from 'react';
import { Bar, BarChart, CartesianGrid, Cell, Line, LineChart, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';

// Context API for state management
const DashboardContext = createContext();

// Custom hook to use dashboard context
const useDashboard = () => {
  const context = useContext(DashboardContext);
  if (!context) {
    throw new Error('useDashboard must be used within DashboardProvider');
  }
  return context;
};

// Provider component to wrap the app
const DashboardProvider = ({ children }) => {
  const [selectedPeriod, setSelectedPeriod] = useState('monthly');
  const [isLoading, setIsLoading] = useState(true);
  const [dashboardData, setDashboardData] = useState({
    sales: [],
    revenue: [],
    customers: [],
    transactions: [],
    performance: [],
    growth: []
  });

  // Simulate loading data (replace with actual API call)
  useEffect(() => {
    setTimeout(() => {
      setIsLoading(false);
      loadDashboardData();
    }, 3000);
  }, []);

  // Function to load data - easily replaceable with API call
  const loadDashboardData = () => {
    // This is where you'll add your JSP API call
    // Example: fetch('/api/dashboard-data').then(res => res.json()).then(data => setDashboardData(data))
    
    setDashboardData({
      sales: [
        { name: 'Jan', value: 4000 },
        { name: 'Feb', value: 3000 },
        { name: 'Mar', value: 5000 },
        { name: 'Apr', value: 4500 }
      ],
      revenue: [
        { name: 'Products', value: 400 },
        { name: 'Services', value: 300 },
        { name: 'Investments', value: 200 }
      ],
      customers: [
        { name: 'Week 1', value: 120 },
        { name: 'Week 2', value: 150 },
        { name: 'Week 3', value: 180 },
        { name: 'Week 4', value: 200 }
      ],
      transactions: [
        { name: 'Mon', value: 2400 },
        { name: 'Tue', value: 1398 },
        { name: 'Wed', value: 9800 },
        { name: 'Thu', value: 3908 },
        { name: 'Fri', value: 4800 }
      ],
      performance: [
        { name: 'Q1', value: 4000 },
        { name: 'Q2', value: 3000 },
        { name: 'Q3', value: 5000 },
        { name: 'Q4', value: 4500 }
      ],
      growth: [
        { name: 'Online', value: 450 },
        { name: 'Offline', value: 350 }
      ]
    });
  };

  return (
    <DashboardContext.Provider value={{ selectedPeriod, setSelectedPeriod, dashboardData, isLoading }}>
      {children}
    </DashboardContext.Provider>
  );
};

// Loading Animation Component
const LoadingAnimation = () => {
  return (
    <div className="fixed inset-0 bg-white z-50 flex items-center justify-center">
      <div className="relative">
        <div className="animate-eye-open">
          <svg width="200" height="200" viewBox="0 0 200 200" className="drop-shadow-2xl">
            {/* Eye outer shape */}
            <ellipse cx="100" cy="100" rx="80" ry="50" fill="#E30613" className="animate-pulse" />
            {/* Eye white */}
            <ellipse cx="100" cy="100" rx="60" ry="35" fill="white" />
            {/* Pupil */}
            <circle cx="100" cy="100" r="20" fill="#E30613" />
            {/* Shine effect */}
            <circle cx="105" cy="95" r="8" fill="white" opacity="0.8" />
          </svg>
        </div>
      </div>
      <style>{`
        @keyframes eye-open {
          0% { transform: scaleY(0); opacity: 0; }
          50% { transform: scaleY(1); opacity: 1; }
          100% { transform: scaleY(1) scale(1.2); opacity: 0; }
        }
        .animate-eye-open {
          animation: eye-open 2.5s ease-in-out forwards;
        }
      `}</style>
    </div>
  );
};

// Stats Card Component
const StatsCard = ({ icon: Icon, title, value, change, isPositive }) => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div
      className="bg-white bg-opacity-80 backdrop-blur-md rounded-xl shadow-lg p-6 border border-red-100 transition-all duration-300 hover:shadow-xl cursor-pointer"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      style={{
        transform: isHovered ? 'translateY(-3px)' : 'translateY(0)',
      }}
    >
      <div className="flex items-center justify-between mb-4">
        <div className={`p-3 rounded-lg ${isPositive ? 'bg-red-50' : 'bg-gray-50'}`}>
          <Icon className={`w-6 h-6 ${isPositive ? 'text-red-600' : 'text-gray-600'}`} />
        </div>
        <div className={`flex items-center gap-1 text-sm font-semibold ${isPositive ? 'text-green-600' : 'text-red-600'}`}>
          {isPositive ? <ArrowUp className="w-4 h-4" /> : <ArrowDown className="w-4 h-4" />}
          {change}
        </div>
      </div>
      <h3 className="text-gray-600 text-sm font-medium mb-1">{title}</h3>
      <p className="text-2xl font-bold text-gray-800">{value}</p>
    </div>
  );
};

// Dropdown Selector Component
const PeriodSelector = () => {
  const { selectedPeriod, setSelectedPeriod } = useDashboard();

  return (
    <div className="flex items-center gap-4">
      <label className="text-gray-700 font-semibold">Process Name:</label>
      <select
        value={selectedPeriod}
        onChange={(e) => setSelectedPeriod(e.target.value)}
        className="px-6 py-3 rounded-lg border-2 border-red-600 text-red-600 font-semibold bg-white hover:bg-red-50 transition-all duration-300 cursor-pointer shadow-md hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-red-500"
      >
        <option value="DBO">DBO</option>
        <option value="PC">PC</option>
        <option value="DAO">DAO</option>
        <option value="KYC">KYC</option>
        <option value="TWC">TWC</option>
      </select>
    </div>
  );
};

// Chart Container Component with glass effect
const ChartContainer = ({ title, children }) => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div
      className="bg-white bg-opacity-80 backdrop-blur-md rounded-2xl shadow-lg p-6 border border-red-100 transition-all duration-300 hover:shadow-2xl"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      style={{
        transform: isHovered ? 'translateY(-5px)' : 'translateY(0)',
      }}
    >
      <h3 className="text-xl font-bold text-red-600 mb-4 flex items-center gap-2">
        <div className="w-1 h-6 bg-red-600 rounded-full"></div>
        {title}
      </h3>
      <div className="h-64">
        {children}
      </div>
    </div>
  );
};

// Sales Chart Component
const SalesChart = () => {
  const { dashboardData } = useDashboard();

  return (
    <ChartContainer title="Sales Overview">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={dashboardData.sales}>
          <CartesianGrid strokeDasharray="3 3" stroke="#ffcccc" />
          <XAxis dataKey="name" stroke="#E30613" />
          <YAxis stroke="#E30613" />
          <Tooltip />
          <Bar dataKey="value" fill="#E30613" radius={[8, 8, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </ChartContainer>
  );
};

// Revenue Chart Component
const RevenueChart = () => {
  const { dashboardData } = useDashboard();
  const COLORS = ['#E30613', '#FF6B6B', '#FFB3B3'];

  return (
    <ChartContainer title="Revenue Distribution">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={dashboardData.revenue}
            cx="50%"
            cy="50%"
            labelLine={false}
            outerRadius={80}
            fill="#8884d8"
            dataKey="value"
            label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
          >
            {dashboardData.revenue.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
            ))}
          </Pie>
          <Tooltip />
        </PieChart>
      </ResponsiveContainer>
    </ChartContainer>
  );
};

// Customer Growth Chart
const CustomerChart = () => {
  const { dashboardData } = useDashboard();

  return (
    <ChartContainer title="Customer Growth">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={dashboardData.customers}>
          <CartesianGrid strokeDasharray="3 3" stroke="#ffcccc" />
          <XAxis dataKey="name" stroke="#E30613" />
          <YAxis stroke="#E30613" />
          <Tooltip />
          <Line type="monotone" dataKey="value" stroke="#E30613" strokeWidth={3} dot={{ fill: '#E30613', r: 5 }} />
        </LineChart>
      </ResponsiveContainer>
    </ChartContainer>
  );
};

// Transactions Chart
const TransactionsChart = () => {
  const { dashboardData } = useDashboard();

  return (
    <ChartContainer title="Daily Transactions">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={dashboardData.transactions}>
          <CartesianGrid strokeDasharray="3 3" stroke="#ffcccc" />
          <XAxis dataKey="name" stroke="#E30613" />
          <YAxis stroke="#E30613" />
          <Tooltip />
          <Bar dataKey="value" fill="#FF6B6B" radius={[8, 8, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </ChartContainer>
  );
};

// Performance Chart
const PerformanceChart = () => {
  const { dashboardData } = useDashboard();

  return (
    <ChartContainer title="Quarterly Performance">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={dashboardData.performance}>
          <CartesianGrid strokeDasharray="3 3" stroke="#ffcccc" />
          <XAxis dataKey="name" stroke="#E30613" />
          <YAxis stroke="#E30613" />
          <Tooltip />
          <Line type="monotone" dataKey="value" stroke="#FF6B6B" strokeWidth={3} dot={{ fill: '#FF6B6B', r: 6 }} />
        </LineChart>
      </ResponsiveContainer>
    </ChartContainer>
  );
};

// Growth Chart
const GrowthChart = () => {
  const { dashboardData } = useDashboard();
  const COLORS = ['#E30613', '#FFB3B3'];

  return (
    <ChartContainer title="Channel Growth">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={dashboardData.growth}
            cx="50%"
            cy="50%"
            innerRadius={50}
            outerRadius={80}
            fill="#8884d8"
            dataKey="value"
            label
          >
            {dashboardData.growth.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
            ))}
          </Pie>
          <Tooltip />
        </PieChart>
      </ResponsiveContainer>
    </ChartContainer>
  );
};

// Main Dashboard Component
const Dashboard = () => {
  const { isLoading } = useDashboard();

  if (isLoading) {
    return <LoadingAnimation />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 via-white to-red-50 p-8">
      {/* Decorative Background Elements */}
      <div className="fixed top-20 right-20 w-64 h-64 bg-red-100 rounded-full blur-3xl opacity-30 pointer-events-none"></div>
      <div className="fixed bottom-20 left-20 w-96 h-96 bg-red-200 rounded-full blur-3xl opacity-20 pointer-events-none"></div>
      
      {/* Header with glass effect */}
      <div className="bg-white bg-opacity-70 backdrop-blur-lg rounded-2xl shadow-xl p-8 mb-8 border border-red-100 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-red-600 rounded-full blur-3xl opacity-10"></div>
        <div className="relative z-10">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-5xl font-bold text-red-600 mb-2">RAKBank Dashboard</h1>
              <p className="text-gray-600 text-lg">Real-time analytics and insights for better decisions</p>
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-500">Last Updated</p>
              <p className="text-lg font-semibold text-gray-800">{new Date().toLocaleTimeString()}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Cards Row */}
      <div className="grid grid-cols-4 gap-6 mb-8">
        <StatsCard 
          icon={DollarSign} 
          title="Total Revenue" 
          value="$124.5K" 
          change="+12.5%" 
          isPositive={true}
        />
        <StatsCard 
          icon={Users} 
          title="Active Users" 
          value="8,549" 
          change="+8.2%" 
          isPositive={true}
        />
        <StatsCard 
          icon={TrendingUp} 
          title="Growth Rate" 
          value="23.4%" 
          change="+3.1%" 
          isPositive={true}
        />
        <StatsCard 
          icon={Activity} 
          title="Transactions" 
          value="1,234" 
          change="-2.4%" 
          isPositive={false}
        />
      </div>

      {/* Period Selector */}
      <div className="mb-8">
        <PeriodSelector />
      </div>

      {/* Dashboard Grid - 2 rows, 3 columns each row */}
      {/* Row 1 - Sales, Revenue, Customer */}
      <div className="grid grid-cols-3 gap-6 mb-8">
        <div className="col-span-1">
          <SalesChart />
        </div>
        <div className="col-span-1">
          <RevenueChart />
        </div>
        <div className="col-span-1">
          <CustomerChart />
        </div>
      </div>

      {/* Row 2 - Transactions, Performance, Growth */}
      <div className="grid grid-cols-3 gap-6 mb-8">
        <div className="col-span-1">
          <TransactionsChart />
        </div>
        <div className="col-span-1">
          <PerformanceChart />
        </div>
        <div className="col-span-1">
          <GrowthChart />
        </div>
      </div>

      {/* Footer Section */}
      <div className="mt-8 bg-white bg-opacity-70 backdrop-blur-lg rounded-2xl shadow-lg p-6 border border-red-100">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-red-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-xl">R</span>
            </div>
            <div>
              <p className="text-sm text-gray-600">Powered by</p>
              <p className="text-lg font-bold text-red-600">RAKBank Analytics</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-sm text-gray-600">Need help?</p>
            <p className="text-red-600 font-semibold cursor-pointer hover:underline">Contact Support</p>
          </div>
        </div>
      </div>
    </div>
  );
};

// Main App Component
const App = () => {
  return (
    <DashboardProvider>
      <Dashboard />
    </DashboardProvider>
  );
};

export default App;